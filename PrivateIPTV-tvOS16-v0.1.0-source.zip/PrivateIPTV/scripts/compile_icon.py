"""Compile the existing blue TV artwork as a native tvOS layered app icon.

Requires Apple's actool from full Xcode. No network access or Apple account.
The back layer contains the existing artwork. A transparent front layer keeps
the original flat design, with no duplicate or offset TV symbol.
"""
import json
import os
from pathlib import Path
import plistlib
import shutil
import struct
import subprocess
import sys
import tempfile
import zlib


def xcode_environment():
    if sys.platform != 'darwin':
        raise RuntimeError('The tvOS icon must be compiled on a Mac with full Xcode.')
    env = os.environ.copy()
    candidates = [env.get('DEVELOPER_DIR'), None]
    candidates += [str(p / 'Contents/Developer') for p in Path('/Applications').glob('Xcode*.app')]
    for candidate in candidates:
        trial = env.copy()
        if candidate:
            trial['DEVELOPER_DIR'] = candidate
        check = subprocess.run(['xcrun', '--sdk', 'appletvos', '--find', 'actool'],
                               env=trial, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
        if check.returncode == 0 and check.stdout.strip():
            return trial
    raise RuntimeError('Full Xcode with the tvOS SDK is required. Command Line Tools alone do not include actool.')


def blank_front(path, width, height):
    # An empty data layer; the existing artwork is copied byte-for-byte below.
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    path.write_bytes(b'\x89PNG\r\n\x1a\n' +
                     chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)) +
                     chunk(b'IDAT', zlib.compress(b'\0' * (height * (width * 4 + 1)), 9)) +
                     chunk(b'IEND', b''))


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(dict(value, info={'author': 'xcode', 'version': 1}), indent=2) + '\n')


def make_catalog(root, app):
    catalog = root / 'Images.xcassets'
    brand = catalog / 'AppIcon.brandassets'
    write_json(catalog / 'Contents.json', {})
    specs = [('App Icon', '400x240', [('1x', 400, 240), ('2x', 800, 480)]),
             ('App Icon - App Store', '1280x768', [('1x', 1280, 768)])]
    write_json(brand / 'Contents.json', {'assets': [
        {'filename': name + '.imagestack', 'idiom': 'tv', 'role': 'primary-app-icon', 'size': size}
        for name, size, scales in specs]})
    for name, size, scales in specs:
        stack = brand / (name + '.imagestack')
        write_json(stack / 'Contents.json', {'layers': [
            {'filename': layer + '.imagestacklayer'} for layer in ('Front', 'Back')]})
        for layer in ('Front', 'Back'):
            directory = stack / (layer + '.imagestacklayer')
            write_json(directory / 'Contents.json', {})
            images = directory / 'Content.imageset'
            write_json(images / 'Contents.json', {'images': [
                {'filename': scale + '.png', 'idiom': 'tv', 'scale': scale} for scale, w, h in scales]})
            for scale, w, h in scales:
                destination = images / (scale + '.png')
                if layer == 'Front':
                    blank_front(destination, w, h)
                elif w in (400, 800):
                    shutil.copy2(app / ('AppIcon.png' if w == 400 else 'AppIcon@2x.png'), destination)
                else:
                    subprocess.run(['/usr/bin/sips', '-z', str(h), str(w),
                                    str(app / 'AppIcon@2x.png'), '--out', str(destination)],
                                   check=True, stdout=subprocess.DEVNULL)
    return catalog


def compile_icon(app):
    env = xcode_environment()
    with tempfile.TemporaryDirectory(prefix='private-tv-icon-') as temporary:
        root = Path(temporary)
        catalog = make_catalog(root, app)
        partial = root / 'IconInfo.plist'
        subprocess.run(['xcrun', '--sdk', 'appletvos', 'actool', str(catalog),
                        '--compile', str(app), '--platform', 'appletvos', '--target-device', 'tv',
                        '--minimum-deployment-target', '16.0', '--app-icon', 'AppIcon',
                        '--output-partial-info-plist', str(partial), '--output-format', 'human-readable-text',
                        '--warnings', '--notices'], env=env, check=True)
        info = plistlib.loads(partial.read_bytes())
        primary = info.get('CFBundleIcons', {}).get('CFBundlePrimaryIcon')
        if not (app / 'Assets.car').is_file() or not isinstance(primary, str) or not primary:
            raise RuntimeError('Xcode did not produce a compiled tvOS primary icon. No IPA was exported.')
        return info
