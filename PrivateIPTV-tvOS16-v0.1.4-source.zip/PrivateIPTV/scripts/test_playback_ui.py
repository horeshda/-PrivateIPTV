#!/usr/bin/env python3
"""Exercise production UIKit controllers using a decoder double on tvOS Simulator."""
import json,os,plistlib,subprocess,tempfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent

def run(*args,**kwargs):
    return subprocess.run(args,check=True,text=True,**kwargs)

def main():
    runtimes=json.loads(subprocess.check_output(['xcrun','simctl','list','runtimes','-j']))['runtimes']
    available=[r for r in runtimes if r.get('isAvailable') and r['name'].startswith('tvOS')]
    report={'status':'not_run','reason':'No installed tvOS Simulator runtime'}
    if not available:
        print('Playback UI regression: SKIPPED (no installed tvOS Simulator runtime).',flush=True)
        return report
    runtime=sorted(available,key=lambda r:tuple(map(int,r['version'].split('.'))))[-1]
    types=json.loads(subprocess.check_output(['xcrun','simctl','list','devicetypes','-j']))['devicetypes']
    device=next(d for d in types if d['name'].startswith('Apple TV 4K'))
    udid=subprocess.check_output(['xcrun','simctl','create','PrivateIPTV playback regression',device['identifier'],runtime['identifier']],text=True).strip()
    try:
        run('xcrun','simctl','boot',udid)
        run('xcrun','simctl','bootstatus',udid,'-b',timeout=180)
        sdk=subprocess.check_output(['xcrun','--sdk','appletvsimulator','--show-sdk-path'],text=True).strip()
        with tempfile.TemporaryDirectory(prefix='iptv-ui-test-') as temp:
            app=Path(temp)/'PlaybackTests.app';app.mkdir()
            (app/'Info.plist').write_bytes(plistlib.dumps({'CFBundleIdentifier':'com.horesh.privateiptv.playbacktests','CFBundleExecutable':'PlaybackTests','CFBundleName':'PlaybackTests','CFBundlePackageType':'APPL','CFBundleVersion':'1','CFBundleShortVersionString':'1.0','MinimumOSVersion':'16.0','UIDeviceFamily':[3],'CFBundleSupportedPlatforms':['AppleTVSimulator'],'UILaunchScreen':{}}))
            sources=[str(p) for p in (ROOT/'Native').glob('*.m') if p.name!='main.m']
            run('xcrun','--sdk','appletvsimulator','clang','-target','arm64-apple-tvos16.0-simulator','-isysroot',sdk,'-fobjc-arc','-fblocks','-O1','-Wno-deprecated-declarations','-I',str(ROOT/'tests/Stubs'),*sources,str(ROOT/'Core/M3U.c'),str(ROOT/'tests/Stubs/TVVLCKit.m'),str(ROOT/'tests/playback_ui.m'),'-framework','UIKit','-framework','Foundation','-framework','AVFoundation','-o',str(app/'PlaybackTests'))
            run('codesign','--force','--sign','-',str(app))
            run('xcrun','simctl','install',udid,str(app))
            launched=subprocess.run(['xcrun','simctl','launch','--console',udid,'com.horesh.privateiptv.playbacktests'],timeout=150,capture_output=True,text=True)
            if launched.returncode:print(launched.stdout[-6000:]+launched.stderr[-6000:],flush=True)
            container=subprocess.check_output(['xcrun','simctl','get_app_container',udid,'com.horesh.privateiptv.playbacktests','data'],text=True).strip()
            result=(Path(container)/'Documents/playback-ui-result.txt').read_text()
            print(result,flush=True)
            if not result.startswith('PASS:'):raise RuntimeError(result)
            report={'status':'passed','runtime':runtime['name'],'cycles':12,'decoder':'blocking test double; no network playback'}
    finally:
        subprocess.run(['xcrun','simctl','shutdown',udid],check=False,capture_output=True)
        subprocess.run(['xcrun','simctl','delete',udid],check=False,capture_output=True)
    return report

if __name__=='__main__':print(json.dumps(main()))
