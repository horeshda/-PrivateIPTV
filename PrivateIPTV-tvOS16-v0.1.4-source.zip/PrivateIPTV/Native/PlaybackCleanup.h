#import <Foundation/Foundation.h>

@protocol IPTVStoppable <NSObject>
- (void)stop;
@end

// Detach delegates and the drawable on main before handing ownership here.
// A slow decoder/network shutdown must never block the UIKit focus engine.
void IPTVStopPlayerAsync(id<IPTVStoppable> player, dispatch_block_t completion);
