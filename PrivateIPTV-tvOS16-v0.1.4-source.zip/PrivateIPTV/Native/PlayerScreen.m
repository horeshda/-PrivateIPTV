#import "PlayerScreen.h"
#import "PlaylistStore.h"
#import "PlaybackCleanup.h"
#import <TVVLCKit/TVVLCKit.h>
#import <AVFoundation/AVFoundation.h>

// Serialize audio activation/deactivation without waiting on the UI thread.
// A quick reopen queues activation after the previous screen's deactivation.
static void SetPlaybackAudioActive(BOOL active) {
    static dispatch_queue_t queue;static dispatch_once_t once;
    dispatch_once(&once,^{queue=dispatch_queue_create("com.horesh.privateiptv.audio",DISPATCH_QUEUE_SERIAL);});
    dispatch_async(queue,^{
        AVAudioSession *audio=AVAudioSession.sharedInstance;
        if(active)[audio setCategory:AVAudioSessionCategoryPlayback mode:AVAudioSessionModeMoviePlayback options:0 error:nil];
        [audio setActive:active withOptions:active?0:AVAudioSessionSetActiveOptionNotifyOthersOnDeactivation error:nil];
    });
}

@interface PlayerScreen () <VLCMediaPlayerDelegate>
@property(nonatomic,strong) NSArray<NSDictionary *> *channels;
@property(nonatomic) NSUInteger index;
@property(nonatomic,strong) PlaylistStore *store;
@property(nonatomic,strong) VLCMediaPlayer *player;
@property(nonatomic,strong) UIView *surface;
@property(nonatomic,strong) UIStackView *controls;
@property(nonatomic,strong) UILabel *titleLabel;
@property(nonatomic,strong) UIActivityIndicatorView *spinner;
@property(nonatomic,strong) UIButton *favoriteButton;
@property(nonatomic,strong) UIButton *pauseButton;
@property(nonatomic,strong) UIButton *retryButton;
@property(nonatomic,strong) NSTimer *hideTimer;
@property(nonatomic,strong) NSTimer *watchdog;
@property(nonatomic) NSUInteger generation;
@property(nonatomic) NSUInteger retries;
@property(nonatomic) BOOL paused;
@property(nonatomic) BOOL closing;
@property(nonatomic) BOOL suppressedSelect;
@property(nonatomic) BOOL subtitlesApplied;
@end
@implementation PlayerScreen
- (instancetype)initWithChannels:(NSArray *)channels index:(NSUInteger)index store:(PlaylistStore *)store {
    if((self=[super init])){_channels=channels;_index=index;_store=store;self.modalPresentationStyle=UIModalPresentationFullScreen;}return self;
}
- (UIButton *)button:(NSString *)title action:(SEL)action {
    UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem];[b setTitle:title forState:UIControlStateNormal];
    b.titleLabel.font=[UIFont systemFontOfSize:28 weight:UIFontWeightSemibold];b.titleLabel.adjustsFontSizeToFitWidth=YES;b.titleLabel.minimumScaleFactor=.9;
    b.contentEdgeInsets=UIEdgeInsetsMake(12,24,12,24);
    [b addTarget:self action:action forControlEvents:UIControlEventPrimaryActionTriggered];return b;
}
- (void)viewDidLoad {
    [super viewDidLoad];self.view.backgroundColor=UIColor.blackColor;self.overrideUserInterfaceStyle=UIUserInterfaceStyleDark;
    self.surface=[UIView new];self.surface.backgroundColor=UIColor.blackColor;self.surface.userInteractionEnabled=NO;[self.view addSubview:self.surface];
    self.titleLabel=[UILabel new];self.titleLabel.textColor=UIColor.whiteColor;self.titleLabel.font=[UIFont systemFontOfSize:30 weight:UIFontWeightSemibold];self.titleLabel.textAlignment=NSTextAlignmentCenter;
    self.titleLabel.layer.shadowColor=UIColor.blackColor.CGColor;self.titleLabel.layer.shadowOpacity=1;self.titleLabel.layer.shadowRadius=4;[self.view addSubview:self.titleLabel];
    self.favoriteButton=[self button:@"☆" action:@selector(favorite)];
    self.pauseButton=[self button:@"Pause" action:@selector(togglePause)];
    self.controls=[[UIStackView alloc]initWithArrangedSubviews:@[[self button:@"Back" action:@selector(close)],[self button:@"Previous" action:@selector(previous)],self.pauseButton,[self button:@"Next" action:@selector(next)],self.favoriteButton,[self button:@"CC" action:@selector(subtitles)],[self button:@"Audio" action:@selector(audio)]]];
    self.controls.axis=UILayoutConstraintAxisHorizontal;self.controls.spacing=20;self.controls.distribution=UIStackViewDistributionFillProportionally;self.controls.semanticContentAttribute=UISemanticContentAttributeForceLeftToRight;
    [self.view addSubview:self.controls];
    self.retryButton=[self button:@"↻" action:@selector(manualRetry)];self.retryButton.accessibilityLabel=@"Retry";self.retryButton.hidden=YES;[self.view addSubview:self.retryButton];
    self.spinner=[[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];self.spinner.hidesWhenStopped=YES;[self.view addSubview:self.spinner];
    NSNotificationCenter *nc=NSNotificationCenter.defaultCenter;
    [nc addObserver:self selector:@selector(background) name:UIApplicationDidEnterBackgroundNotification object:nil];
    [nc addObserver:self selector:@selector(interrupted:) name:AVAudioSessionInterruptionNotification object:nil];
    for(NSNumber *direction in @[@(UISwipeGestureRecognizerDirectionUp),@(UISwipeGestureRecognizerDirectionDown),@(UISwipeGestureRecognizerDirectionLeft),@(UISwipeGestureRecognizerDirectionRight)]){
        UISwipeGestureRecognizer *g=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(wake:)];g.direction=direction.unsignedIntegerValue;g.cancelsTouchesInView=NO;[self.view addGestureRecognizer:g];
    }
    [self start];
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];CGRect b=self.view.bounds;CGFloat s=b.size.width/1920;
    self.surface.frame=b;self.titleLabel.frame=CGRectMake(100*s,60*s,b.size.width-200*s,70*s);
    self.controls.frame=CGRectMake(110*s,b.size.height-170*s,b.size.width-220*s,80*s);
    self.controls.spacing=20*s;
    for(UIButton *button in self.controls.arrangedSubviews){button.titleLabel.font=[UIFont systemFontOfSize:28*s weight:UIFontWeightSemibold];button.contentEdgeInsets=UIEdgeInsetsMake(12*s,24*s,12*s,24*s);}
    self.spinner.center=CGPointMake(b.size.width/2,b.size.height/2);
    self.retryButton.frame=CGRectMake(b.size.width/2-60*s,b.size.height/2-50*s,120*s,100*s);
}
- (NSArray<id<UIFocusEnvironment>> *)preferredFocusEnvironments{return self.retryButton.hidden?@[self.pauseButton]:@[self.retryButton];}
- (void)releasePlayer {
    [self.watchdog invalidate];self.watchdog=nil;
    VLCMediaPlayer *retired=self.player;self.player=nil;
    if(!retired)return;
    retired.delegate=nil;
    // Detach before stop can take the decoder's locks; never reuse its surface.
    UIView *surface=self.surface;
    retired.drawable=nil;
    IPTVStopPlayerAsync((id<IPTVStoppable>)retired,^{[surface removeFromSuperview];});
}
- (void)start {
    if(self.closing||self.index>=self.channels.count)return;
    self.generation++;self.paused=NO;self.subtitlesApplied=NO;[self releasePlayer];
    NSDictionary *c=self.channels[self.index];self.titleLabel.text=c[@"name"];
    [self.favoriteButton setTitle:[self.store.favorites containsObject:c[@"id"]]?@"★":@"☆" forState:UIControlStateNormal];
    [self.pauseButton setTitle:@"Pause" forState:UIControlStateNormal];
    self.retryButton.hidden=YES;[self.spinner startAnimating];
    SetPlaybackAudioActive(YES);UIApplication.sharedApplication.idleTimerDisabled=YES;
    [self.surface removeFromSuperview];
    self.surface=[[UIView alloc]initWithFrame:self.view.bounds];self.surface.backgroundColor=UIColor.blackColor;self.surface.userInteractionEnabled=NO;
    [self.view insertSubview:self.surface atIndex:0];
    self.player=[[VLCMediaPlayer alloc]initWithOptions:@[@"--no-video-title-show",@"--quiet"]];
    self.player.drawable=self.surface;self.player.delegate=self;
    VLCMedia *media=[VLCMedia mediaWithURL:[NSURL URLWithString:c[@"url"]]];
    [media addOption:@":network-caching=1500"];[media addOption:@":http-reconnect"];
    NSDictionary *headers=c[@"headers"];
    if([headers[@"User-Agent"] isKindOfClass:NSString.class]&&[headers[@"User-Agent"] length])[media addOption:[@":http-user-agent=" stringByAppendingString:headers[@"User-Agent"]]];
    if([headers[@"Referer"] isKindOfClass:NSString.class]&&[headers[@"Referer"] length])[media addOption:[@":http-referrer=" stringByAppendingString:headers[@"Referer"]]];
    self.player.media=media;[self.player play];[self showControls];[self armWatchdog];
}
- (void)armWatchdog {
    if(self.watchdog||self.paused||self.closing)return;
    NSUInteger g=self.generation;__weak PlayerScreen *weak=self;
    self.watchdog=[NSTimer scheduledTimerWithTimeInterval:30 repeats:NO block:^(NSTimer *t){PlayerScreen *s=weak;if(s&&s.generation==g)[s failed];}];
}
- (void)failed {
    if(self.closing||self.paused||!self.retryButton.hidden)return;
    [self releasePlayer];[self.spinner stopAnimating];
    if(self.retries++<1){
        NSUInteger g=++self.generation;__weak PlayerScreen *weak=self;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{PlayerScreen *s=weak;if(s&&!s.closing&&s.generation==g)[s start];});
    }else{self.retryButton.hidden=NO;UIApplication.sharedApplication.idleTimerDisabled=NO;[self showControls];[self setNeedsFocusUpdate];[self updateFocusIfNeeded];}
}
- (void)mediaPlayerStateChanged:(NSNotification *)notification {
    VLCMediaPlayer *sender=notification.object;
    dispatch_async(dispatch_get_main_queue(), ^{
        if(self.closing||sender!=self.player)return;
        VLCMediaPlayerState state=self.player.state;
        if(state==VLCMediaPlayerStatePlaying){
            [self.watchdog invalidate];self.watchdog=nil;[self.spinner stopAnimating];
            [self applySubtitlePreference];
        }else if(state==VLCMediaPlayerStateBuffering||state==VLCMediaPlayerStateOpening){[self.spinner startAnimating];[self armWatchdog];}
        else if(state==VLCMediaPlayerStateError){[self failed];}
        else if(state==VLCMediaPlayerStateEnded){[self.watchdog invalidate];self.watchdog=nil;[self.spinner stopAnimating];self.retryButton.hidden=NO;UIApplication.sharedApplication.idleTimerDisabled=NO;[self showControls];}
    });
}
- (void)mediaPlayerTimeChanged:(NSNotification *)notification {
    VLCMediaPlayer *sender=notification.object;
    dispatch_async(dispatch_get_main_queue(), ^{
        if(sender!=self.player||self.closing)return;
        [self applySubtitlePreference];
        if(self.player.isPlaying){[self.watchdog invalidate];self.watchdog=nil;[self.spinner stopAnimating];}
    });
}
- (void)applySubtitlePreference {
    if(self.subtitlesApplied)return;
    NSNumber *enabled=[NSUserDefaults.standardUserDefaults objectForKey:@"PrivateIPTV.subtitles.enabled"];
    if(enabled&&!enabled.boolValue){self.player.currentVideoSubTitleIndex=-1;self.subtitlesApplied=YES;return;}
    NSString *preferred=[NSUserDefaults.standardUserDefaults stringForKey:@"PrivateIPTV.subtitles.name"];
    if(preferred){
        NSUInteger index=[self.player.videoSubTitlesNames indexOfObject:preferred];
        if(index!=NSNotFound&&index<self.player.videoSubTitlesIndexes.count){self.player.currentVideoSubTitleIndex=[self.player.videoSubTitlesIndexes[index] intValue];self.subtitlesApplied=YES;}
    }
}
- (void)showControls {
    if(self.closing)return;
    self.controls.hidden=NO;self.titleLabel.hidden=NO;[self.hideTimer invalidate];
    __weak PlayerScreen *weak=self;
    self.hideTimer=[NSTimer scheduledTimerWithTimeInterval:5 repeats:NO block:^(NSTimer *timer){PlayerScreen *s=weak;if(s&&!s.paused&&!s.presentedViewController&&s.retryButton.hidden){s.controls.hidden=YES;s.titleLabel.hidden=YES;}}];
}
- (void)wake:(id)sender {[self showControls];}
- (void)didUpdateFocusInContext:(UIFocusUpdateContext *)context withAnimationCoordinator:(UIFocusAnimationCoordinator *)coordinator {
    [super didUpdateFocusInContext:context withAnimationCoordinator:coordinator];if(!self.controls.hidden)[self showControls];
}
- (void)favorite {[self.store toggleFavorite:self.channels[self.index][@"id"]];[self.favoriteButton setTitle:[self.store.favorites containsObject:self.channels[self.index][@"id"]]?@"★":@"☆" forState:UIControlStateNormal];[self showControls];}
- (void)previous {if(self.index>0){self.index--;self.retries=0;[self start];}}
- (void)next {if(self.index+1<self.channels.count){self.index++;self.retries=0;[self start];}}
- (void)manualRetry {self.retries=0;[self start];}
- (void)togglePause {
    if(self.closing)return;
    if(!self.player){[self manualRetry];return;}
    self.paused=!self.paused;
    if(self.paused){[self.player pause];[self.watchdog invalidate];self.watchdog=nil;[self.spinner stopAnimating];}
    else{[self.player play];[self armWatchdog];}
    UIApplication.sharedApplication.idleTimerDisabled=!self.paused;
    [self.pauseButton setTitle:self.paused?@"Play":@"Pause" forState:UIControlStateNormal];[self showControls];
}
- (void)trackMenu:(BOOL)subtitle {
    [self.hideTimer invalidate];
    NSArray *names=subtitle?self.player.videoSubTitlesNames:self.player.audioTrackNames;
    NSArray *indices=subtitle?self.player.videoSubTitlesIndexes:self.player.audioTrackIndexes;
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:subtitle?@"Subtitles":@"Audio track" message:names.count?nil:@"No additional tracks in this stream." preferredStyle:UIAlertControllerStyleActionSheet];
    if(subtitle)[alert addAction:[UIAlertAction actionWithTitle:@"Off" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a){self.player.currentVideoSubTitleIndex=-1;[NSUserDefaults.standardUserDefaults setBool:NO forKey:@"PrivateIPTV.subtitles.enabled"];self.subtitlesApplied=YES;[self showControls];}]];
    for(NSUInteger i=0;i<MIN(names.count,indices.count);i++){
        int track=[indices[i] intValue];if(track<0)continue;NSString *name=[names[i] description];
        [alert addAction:[UIAlertAction actionWithTitle:name style:UIAlertActionStyleDefault handler:^(UIAlertAction *a){
            if(subtitle){self.player.currentVideoSubTitleIndex=track;self.subtitlesApplied=YES;[NSUserDefaults.standardUserDefaults setBool:YES forKey:@"PrivateIPTV.subtitles.enabled"];[NSUserDefaults.standardUserDefaults setObject:name forKey:@"PrivateIPTV.subtitles.name"];}
            else self.player.currentAudioTrackIndex=track;[self showControls];
        }]];
    }
    [alert addAction:[UIAlertAction actionWithTitle:@"Back" style:UIAlertActionStyleCancel handler:^(UIAlertAction *a){[self showControls];}]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)subtitles {[self trackMenu:YES];}
- (void)audio {[self trackMenu:NO];}
- (void)background {if(!self.paused&&self.player)[self togglePause];}
- (void)interrupted:(NSNotification *)note {if([note.userInfo[AVAudioSessionInterruptionTypeKey] integerValue]==AVAudioSessionInterruptionTypeBegan)[self background];}
- (void)beginClosing {
    if(self.closing)return;
    self.closing=YES;self.generation++;self.suppressedSelect=NO;
    [self.hideTimer invalidate];self.hideTimer=nil;
    [NSNotificationCenter.defaultCenter removeObserver:self];
    [self releasePlayer];UIApplication.sharedApplication.idleTimerDisabled=NO;SetPlaybackAudioActive(NO);
    void (^callback)(NSString *)=self.willClose;self.willClose=nil;
    if(callback)callback(self.index<self.channels.count?self.channels[self.index][@"id"]:nil);
}
- (void)close {
    if(self.closing)return;
    [self beginClosing];[self dismissViewControllerAnimated:YES completion:nil];
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    if(self.isBeingDismissed||self.presentingViewController.isBeingDismissed)[self beginClosing];
}
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    if(!self.presentingViewController)[self beginClosing];
}
- (void)pressesBegan:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {
    if(self.closing)return;
    for(UIPress *p in presses){
        if(p.type==UIPressTypeMenu){if(self.controls.hidden)[self showControls];else [self close];return;}
        if(p.type==UIPressTypePlayPause){[self togglePause];return;}
        if(self.controls.hidden){[self showControls];self.suppressedSelect=YES;return;}
    }[super pressesBegan:presses withEvent:event];
}
- (void)pressesEnded:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {if(self.suppressedSelect){self.suppressedSelect=NO;return;}[super pressesEnded:presses withEvent:event];}
- (void)pressesCancelled:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {
    self.suppressedSelect=NO;[super pressesCancelled:presses withEvent:event];
}
- (void)dealloc {
    [NSNotificationCenter.defaultCenter removeObserver:self];[_hideTimer invalidate];[_watchdog invalidate];
    _player.delegate=nil;_player.drawable=nil;
    if(_player)IPTVStopPlayerAsync((id<IPTVStoppable>)_player,nil);
}
@end
