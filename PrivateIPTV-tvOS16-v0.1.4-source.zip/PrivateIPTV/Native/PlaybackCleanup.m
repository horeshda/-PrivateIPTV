#import "PlaybackCleanup.h"

void IPTVStopPlayerAsync(id<IPTVStoppable> player, dispatch_block_t completion) {
    __block id<IPTVStoppable> retired=player;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0), ^{
        @autoreleasepool {
            [retired stop];
            retired=nil;
        }
        if(completion)dispatch_async(dispatch_get_main_queue(),completion);
    });
}
