#import <UIKit/UIKit.h>
#import "../Native/LibraryScreen.h"
#import "../Native/PlayerScreen.h"
#import "../Native/PlaylistStore.h"
#import "Stubs/TVVLCKit/TVVLCKit.h"

@interface LibraryScreen(Testing)
- (void)reload;
- (void)restorePlaybackFocus;
@end
@interface PlayerScreen(Testing)
- (void)close;
- (void)next;
- (void)favorite;
@end
@interface TestApp:NSObject<UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) LibraryScreen *library;
@property(nonatomic) NSUInteger cycle;
@property(nonatomic) NSUInteger expectedStops;
@end
@implementation TestApp
- (void)finish:(NSString *)error {
    NSString *message=error?[@"FAIL: " stringByAppendingString:error]:@"PASS: 12 playback returns, focus restoration, changed favorites, hidden controls, next channel and blocking decoder teardown.";
    NSString *path=[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/playback-ui-result.txt"];
    [message writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    puts(message.UTF8String);fflush(stdout);exit(error?1:0);
}
- (BOOL)application:(UIApplication *)app didFinishLaunchingWithOptions:(NSDictionary *)options {
    [NSUserDefaults.standardUserDefaults removeObjectForKey:@"PrivateIPTV.library.v1"];
    self.library=[LibraryScreen new];self.window=[[UIWindow alloc]initWithFrame:UIScreen.mainScreen.bounds];self.window.rootViewController=self.library;[self.window makeKeyAndVisible];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{[self seed];});return YES;
}
- (void)seed {
    PlaylistStore *store=[self.library valueForKey:@"store"];
    NSString *sid=NSUUID.UUID.UUIDString;
    NSMutableArray *channels=[NSMutableArray new];
    for(NSUInteger i=0;i<30;i++)[channels addObject:@{@"id":[NSString stringWithFormat:@"test-%lu",(unsigned long)i],@"source":sid,@"name":[NSString stringWithFormat:@"Channel %lu",(unsigned long)i],@"group":@"Test",@"logo":@"",@"url":@"https://example.org/test.m3u8",@"headers":@{}}];
    [[store valueForKey:@"mutableSources"] addObject:@{@"id":sid,@"name":@"Test",@"url":@"https://example.org/test.m3u"}];
    [store valueForKey:@"mutableCatalog"][sid]=channels;
    [self.library reload];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{[self openPlayer];});
}
- (void)openPlayer {
    if(self.cycle==12){
        if(IPTVTestStops!=self.expectedStops||IPTVTestMainCallbacks!=self.expectedStops){[self finish:@"decoder cleanup did not complete"];return;}
        [self finish:nil];return;
    }
    UICollectionView *grid=[self.library valueForKey:@"grid"];
    NSIndexPath *path=[NSIndexPath indexPathForItem:8+self.cycle inSection:0];
    [grid.delegate collectionView:grid didSelectItemAtIndexPath:path];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(.6*NSEC_PER_SEC)),dispatch_get_main_queue(),^{
        PlayerScreen *player=(PlayerScreen *)self.library.presentedViewController;
        if(![player isKindOfClass:PlayerScreen.class]){[self finish:@"player did not open"];return;}
        if(self.cycle%2==0){[player next];self.expectedStops++;}
        if(self.cycle%3==0)[player favorite];
        if(self.cycle%2==1)[[player valueForKey:@"controls"] setHidden:YES];
        self.expectedStops++;
        if(self.cycle%4==3)[self.library dismissViewControllerAnimated:YES completion:nil];else [player close];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{[self checkReturn];});
    });
}
- (void)checkReturn {
    if(self.library.presentedViewController){[self finish:@"player still intercepts input"];return;}
    UICollectionView *grid=[self.library valueForKey:@"grid"];
    NSUInteger index=8+self.cycle+(self.cycle%2==0?1:0);
    NSIndexPath *path=[NSIndexPath indexPathForItem:index inSection:0];
    UICollectionViewCell *cell=[grid cellForItemAtIndexPath:path];
    id focused=[UIFocusSystem focusSystemForEnvironment:self.library.view].focusedItem;
    if(!cell||focused!=cell){[self finish:[NSString stringWithFormat:@"focus missing/wrong after cycle %lu: %@",(unsigned long)self.cycle,focused]];return;}
    self.cycle++;[self openPlayer];
}
@end
int main(int argc,char **argv){@autoreleasepool{return UIApplicationMain(argc,argv,nil,NSStringFromClass(TestApp.class));}}
