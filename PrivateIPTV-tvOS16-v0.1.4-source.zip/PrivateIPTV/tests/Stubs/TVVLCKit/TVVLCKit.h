#import <Foundation/Foundation.h>
typedef NS_ENUM(NSInteger,VLCMediaPlayerState){VLCMediaPlayerStateStopped,VLCMediaPlayerStateOpening,VLCMediaPlayerStateBuffering,VLCMediaPlayerStatePlaying,VLCMediaPlayerStatePaused,VLCMediaPlayerStateEnded,VLCMediaPlayerStateError};
@protocol VLCMediaPlayerDelegate <NSObject>
- (void)mediaPlayerStateChanged:(NSNotification *)notification;
- (void)mediaPlayerTimeChanged:(NSNotification *)notification;
@end
@interface VLCMedia:NSObject
+ (instancetype)mediaWithURL:(NSURL *)url;
- (void)addOption:(NSString *)option;
@end
@interface VLCMediaPlayer:NSObject
@property(nonatomic,weak) id<VLCMediaPlayerDelegate> delegate;
@property(nonatomic,strong) id drawable;
@property(nonatomic,strong) VLCMedia *media;
@property(nonatomic) VLCMediaPlayerState state;
@property(nonatomic,getter=isPlaying) BOOL playing;
@property(nonatomic) int currentVideoSubTitleIndex;
@property(nonatomic) int currentAudioTrackIndex;
@property(nonatomic,strong) NSNumber *testSubtitleSize;
- (void)setTextRendererFontSize:(NSNumber *)size;
@property(nonatomic,strong) NSArray *videoSubTitlesNames,*videoSubTitlesIndexes,*audioTrackNames,*audioTrackIndexes;
- (instancetype)initWithOptions:(NSArray *)options;
- (void)play;
- (void)pause;
- (void)stop;
@end
extern NSUInteger IPTVTestStops;
extern NSUInteger IPTVTestMainCallbacks;
