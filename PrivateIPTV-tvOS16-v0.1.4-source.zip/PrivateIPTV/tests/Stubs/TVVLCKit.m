#import "TVVLCKit/TVVLCKit.h"
#include <assert.h>
NSUInteger IPTVTestStops=0,IPTVTestMainCallbacks=0;
@implementation VLCMedia
+ (instancetype)mediaWithURL:(NSURL *)url{return [self new];}
- (void)addOption:(NSString *)option{}
@end
@implementation VLCMediaPlayer
- (instancetype)initWithOptions:(NSArray *)options{return [self init];}
- (void)play {self.playing=YES;self.state=VLCMediaPlayerStatePlaying;[self.delegate mediaPlayerStateChanged:[NSNotification notificationWithName:@"test" object:self]];}
- (void)pause {self.playing=NO;self.state=VLCMediaPlayerStatePaused;}
- (void)stop {
    // Model a decoder shutdown that needs the main thread: the former
    // synchronous stop on main would fail here or deadlock a real decoder.
    assert(!NSThread.isMainThread);assert(!self.delegate);assert(!self.drawable);
    dispatch_sync(dispatch_get_main_queue(),^{IPTVTestMainCallbacks++;});
    [NSThread sleepForTimeInterval:.05];
    dispatch_sync(dispatch_get_main_queue(),^{IPTVTestStops++;});
}
@end
