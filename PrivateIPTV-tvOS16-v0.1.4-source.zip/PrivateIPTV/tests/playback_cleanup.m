#import <Foundation/Foundation.h>
#import "../Native/PlaybackCleanup.h"
#include <assert.h>
@interface BlockingDecoder:NSObject<IPTVStoppable>
@property(nonatomic,copy) dispatch_block_t stopped;
@end
@implementation BlockingDecoder
- (void)stop {
    assert(!NSThread.isMainThread);
    dispatch_sync(dispatch_get_main_queue(),self.stopped);
}
@end
int main(void){@autoreleasepool{
    __block NSUInteger callbacks=0,finished=0;
    for(NSUInteger i=0;i<20;i++){
        BlockingDecoder *decoder=[BlockingDecoder new];decoder.stopped=^{assert(NSThread.isMainThread);callbacks++;};
        IPTVStopPlayerAsync(decoder,^{assert(NSThread.isMainThread);finished++;});
    }
    NSDate *deadline=[NSDate dateWithTimeIntervalSinceNow:10];
    while(finished<20&&deadline.timeIntervalSinceNow>0)[NSRunLoop.currentRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:.01]];
    assert(callbacks==20&&finished==20);
    puts("Playback cleanup: 20 blocking decoder stops completed off main; main-thread callbacks remained responsive.");
}return 0;}
