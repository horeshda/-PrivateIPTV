#include "../Core/M3U.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct {int n;char name[512],group[512],url[1024],ua[256],ref[256],logo[512],id[128];} Result;
static int collect(const M3UEntry *e,void *p){
    Result *r=p;r->n++;
    snprintf(r->name,sizeof(r->name),"%s",e->name);snprintf(r->group,sizeof(r->group),"%s",e->group);
    snprintf(r->url,sizeof(r->url),"%s",e->url);snprintf(r->ua,sizeof(r->ua),"%s",e->user_agent);
    snprintf(r->ref,sizeof(r->ref),"%s",e->referrer);snprintf(r->logo,sizeof(r->logo),"%s",e->logo);
    snprintf(r->id,sizeof(r->id),"%s",e->tvg_id);return 1;
}
static Result parse(const char *s,int expected){Result r={0};assert(m3u_parse(s,strlen(s),collect,&r)==expected);return r;}
int main(void){
    Result r=parse("\xef\xbb\xbf#EXTM3U\r\n#EXTINF:-1 tvg-id=\"id-1\" group-title=\"News, Israel\" tvg-logo=\"/logo.png\",כאן 11\r\nhttps://example.org/live.m3u8?x=1&y=2\r\n",M3U_OK);
    assert(r.n==1&&!strcmp(r.name,"כאן 11")&&!strcmp(r.group,"News, Israel")&&!strcmp(r.id,"id-1"));
    assert(!strcmp(r.logo,"/logo.png")&&!strcmp(r.url,"https://example.org/live.m3u8?x=1&y=2"));
    r=parse("#EXTM3U\n#EXTINF:-1 group-title='A' tvg-name=\"Name\",\n#EXTGRP:Sports\n#EXTVLCOPT:http-user-agent=Example/1\n#EXTVLCOPT:http-referrer=https://example.org/\n../live/one.ts\n",M3U_OK);
    assert(!strcmp(r.name,"Name")&&!strcmp(r.group,"Sports")&&!strcmp(r.ua,"Example/1")&&!strcmp(r.ref,"https://example.org/"));
    r=parse("#EXTINF:-1,One\n#EXTVLCOPT:http-user-agent=A\nhttps://e.org/1\n#EXTINF:-1,Two\nhttps://e.org/2",M3U_OK);assert(r.n==2&&!r.ua[0]);
    r=parse("#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000\nvariant.m3u8",M3U_HLS);assert(r.n==0);
    r=parse("#EXTM3U\n#EXT-X-TARGETDURATION:6\n#EXTINF:6,\nsegment.ts",M3U_HLS);assert(r.n==0);
    r=parse("https://e.org/1\n\n# comment\nhttp://e.org/2",M3U_OK);assert(r.n==2);
    parse("<html>Unauthorized</html>",M3U_EMPTY);parse("",M3U_EMPTY);parse("#EXTM3U\n#EXTINF:-1,Missing",M3U_EMPTY);
    r=parse("#EXTINF:-1 group-title=\"A\",Movie, Part 2\nhttps://e.org/m.mp4|User-Agent=X%2FY",M3U_OK);assert(!strcmp(r.name,"Movie, Part 2"));
    char zero[]={ 'a',0,'b' };assert(m3u_parse(zero,3,collect,&r)==M3U_LIMIT);
    const size_t large_capacity=2500000;
    char *large=malloc(large_capacity);assert(large);size_t used=0;
    for(int i=0;i<20000;i++){
        int written=snprintf(large+used,large_capacity-used,"#EXTINF:-1 group-title=\"G\",Channel %d\nhttps://e.org/%d\n",i,i);
        assert(written>=0&&(size_t)written<large_capacity-used);
        used+=(size_t)written;
    }
    r=parse(large,M3U_OK);assert(r.n==20000);free(large);
    unsigned seed=13;
    for(int i=0;i<2000;i++){
        char input[1024];for(size_t n=0;n<sizeof(input);n++){seed=seed*1664525u+1013904223u;input[n]=(char)(1+(seed%126));}
        r=(Result){0};(void)m3u_parse(input,sizeof(input),collect,&r);
    }
    puts("Parser: metadata, Hebrew, BOM, CRLF, headers, relative URLs, HLS detection, invalid input, 20,000 channels and fuzz smoke passed.");
    return 0;
}
