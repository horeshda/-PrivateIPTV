#import <Foundation/Foundation.h>
#import "../Native/PlaylistStore.m"
#include <assert.h>
int main(void){@autoreleasepool{
    NSURL *base=[NSURL URLWithString:@"https://example.org/path/list.m3u"];
    M3UEntry entry={"כאן 11","חדשות","../logo.png","11","../live/11.m3u8|User-Agent=My%20Player&Referer=https%3A%2F%2Fexample.org%2F","",""};
    NSDictionary *c=ParseChannel(&entry,base,@"test-source");
    assert([c[@"url"] isEqual:@"https://example.org/live/11.m3u8"]);
    assert([c[@"logo"] isEqual:@"https://example.org/logo.png"]);
    assert([c[@"headers"][@"User-Agent"] isEqual:@"My Player"]);
    assert([c[@"headers"][@"Referer"] isEqual:@"https://example.org/"]);
    assert([c[@"name"] isEqual:@"כאן 11"]);
    assert([c[@"id"] isEqual:ParseChannel(&entry,base,@"test-source")[@"id"]]);
    assert(![c[@"id"] isEqual:ParseChannel(&entry,base,@"other-source")[@"id"]]);
    entry.url="file:///private/data";assert(!ParseChannel(&entry,base,@"s"));
    entry.url="javascript:alert(1)";assert(!ParseChannel(&entry,base,@"s"));
    entry.url="https://example.org/live.ts|User-Agent=x%0D%0Ay";
    c=ParseChannel(&entry,base,@"s");assert(!c[@"headers"][@"User-Agent"]);
    assert([PlaylistStore URLFromText:@" https://example.org/get.php?u=a&p=b&type=m3u_plus \n"]);
    assert(![PlaylistStore URLFromText:@"https://example.org/bad url"]);
    assert(![PlaylistStore URLFromText:@"file:///tmp/test"]);
    assert(![PlaylistStore URLFromText:(id)@123]);
    puts("Foundation adapter: relative URLs, Hebrew, HTTP headers, stable IDs and URL validation passed.");
}return 0;}
