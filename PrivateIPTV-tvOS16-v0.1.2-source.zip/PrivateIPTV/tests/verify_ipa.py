#!/usr/bin/env python3
"""Check platform, deployment target, arm64, embedded framework and icon."""
import plistlib
import struct
import sys
import zipfile

def macho(data):
    assert struct.unpack_from('<I', data)[0] == 0xfeedfacf, 'Expected thin 64-bit Mach-O'
    assert struct.unpack_from('<I', data, 4)[0] == 0x100000c, 'Expected arm64'
    count = struct.unpack_from('<I', data, 16)[0]
    offset = 32; platform = None; minimum = None; signature = False
    for _ in range(count):
        command, size = struct.unpack_from('<II', data, offset)
        assert size >= 8 and offset + size <= len(data)
        if command == 0x32:
            platform, minimum = struct.unpack_from('<II', data, offset + 8)
        elif command == 0x2f:
            platform = 3; minimum = struct.unpack_from('<I', data, offset + 8)[0]
        if command == 0x1d: signature = True
        offset += size
    assert platform == 3, 'Expected tvOS device platform (not simulator or iOS)'
    assert minimum is not None and minimum <= (16 << 16), 'Requires newer than tvOS 16'
    assert signature, 'Missing ad-hoc signature'

with zipfile.ZipFile(sys.argv[1]) as archive:
    assert archive.testzip() is None
    root = 'Payload/PrivateIPTV.app/'
    info = plistlib.loads(archive.read(root + 'Info.plist'))
    assert info['CFBundleIdentifier'] == 'com.horesh.privateiptv.tvos'
    assert info['CFBundleSupportedPlatforms'] == ['AppleTVOS']
    assert info['UIDeviceFamily'] == [3]
    assert info['MinimumOSVersion'] == '16.0'
    assert info.get('CFBundleIcons', {}).get('CFBundlePrimaryIcon')
    assert len(archive.read(root + 'Assets.car')) > 100
    macho(archive.read(root + 'PrivateIPTV'))
    assert (archive.getinfo(root + 'PrivateIPTV').external_attr >> 16) & 0o111
    macho(archive.read(root + 'Frameworks/TVVLCKit.framework/TVVLCKit'))
    assert root + '_CodeSignature/CodeResources' in archive.namelist()
    assert any(n.startswith(root + 'Acknowledgements/VideoLAN-') for n in archive.namelist())
print('IPA validated: tvOS device / arm64 / minimum 16 / framework / icon / signatures.')
