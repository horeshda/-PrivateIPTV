#import <UIKit/UIKit.h>
@class PlaylistStore;
@interface PlayerScreen : UIViewController
- (instancetype)initWithChannels:(NSArray<NSDictionary *> *)channels index:(NSUInteger)index store:(PlaylistStore *)store;
@end
