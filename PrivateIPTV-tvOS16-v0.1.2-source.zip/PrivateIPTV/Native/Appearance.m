#import "Appearance.h"

static NSString *const AppearanceKey=@"PrivateIPTV.appearance";

NSString *IPTVAppearanceName(void) {
    NSString *name=[NSUserDefaults.standardUserDefaults stringForKey:AppearanceKey];
    return name&&[@[@"Light",@"Dark",@"System"] containsObject:name]?name:@"Light";
}
void IPTVApplyAppearance(UIWindow *window) {
    NSString *name=IPTVAppearanceName();
    window.overrideUserInterfaceStyle=[name isEqual:@"Dark"]?UIUserInterfaceStyleDark:
        ([name isEqual:@"Light"]?UIUserInterfaceStyleLight:UIUserInterfaceStyleUnspecified);
}
void IPTVSetAppearance(NSString *name, UIWindow *window) {
    if(!name||![@[@"Light",@"Dark",@"System"] containsObject:name])return;
    [NSUserDefaults.standardUserDefaults setObject:name forKey:AppearanceKey];
    IPTVApplyAppearance(window);
}
UIColor *IPTVBackgroundColor(void) {
    return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *traits){
        return traits.userInterfaceStyle==UIUserInterfaceStyleDark?
            [UIColor colorWithRed:.055 green:.065 blue:.085 alpha:1]:UIColor.whiteColor;
    }];
}
UIColor *IPTVTextColor(void) {
    return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *traits){
        return traits.userInterfaceStyle==UIUserInterfaceStyleDark?
            [UIColor colorWithWhite:.95 alpha:1]:[UIColor colorWithRed:.12 green:.15 blue:.19 alpha:1];
    }];
}
UIColor *IPTVCardColor(void) {
    return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *traits){
        return traits.userInterfaceStyle==UIUserInterfaceStyleDark?
            [UIColor colorWithRed:.14 green:.16 blue:.20 alpha:1]:[UIColor colorWithWhite:.91 alpha:1];
    }];
}
UIColor *IPTVAccentColor(void) {
    return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *traits){
        return traits.userInterfaceStyle==UIUserInterfaceStyleDark?
            [UIColor colorWithRed:.35 green:.65 blue:1 alpha:1]:[UIColor colorWithRed:.08 green:.38 blue:.8 alpha:1];
    }];
}
