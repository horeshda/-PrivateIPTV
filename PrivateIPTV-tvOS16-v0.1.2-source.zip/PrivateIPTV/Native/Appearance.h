#import <UIKit/UIKit.h>

NSString *IPTVAppearanceName(void);
void IPTVApplyAppearance(UIWindow *window);
void IPTVSetAppearance(NSString *name, UIWindow *window);
UIColor *IPTVBackgroundColor(void);
UIColor *IPTVTextColor(void);
UIColor *IPTVCardColor(void);
UIColor *IPTVAccentColor(void);
