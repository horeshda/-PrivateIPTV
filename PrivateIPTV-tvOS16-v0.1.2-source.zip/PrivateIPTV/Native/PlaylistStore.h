#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
@interface PlaylistStore : NSObject
@property(nonatomic,readonly) NSArray<NSDictionary *> *sources;
@property(nonatomic,readonly) NSDictionary<NSString *,NSArray<NSDictionary *> *> *catalog;
@property(nonatomic,readonly) NSSet<NSString *> *favorites;
@property(nonatomic,copy,nullable) void (^changed)(void);
+ (nullable NSURL *)URLFromText:(NSString *)text;
- (NSUUID *)loadName:(NSString *)name url:(NSURL *)url sourceID:(nullable NSString *)sourceID completion:(void (^)(NSString * _Nullable))completion;
- (void)cancel:(NSUUID *)request;
- (void)removeSource:(NSString *)sourceID;
- (void)toggleFavorite:(NSString *)channelID;
@end
NS_ASSUME_NONNULL_END
