# Dependencies

Private IPTV uses the unmodified TVVLCKit 3.7.4 dynamic framework from VideoLAN.
VLCKit and libVLC are distributed under LGPL 2.1 or later. Binary license notices
are included with the application in Acknowledgements. The build verifies the
archive using the SHA-256 recorded in the CocoaPods TVVLCKit 3.7.4 specification.

- Project and source: https://code.videolan.org/videolan/VLCKit
- Source mirror: https://github.com/videolan/vlckit/tree/3.0
- libVLC source: https://code.videolan.org/videolan/vlc
- Binary archive: https://download.videolan.org/cocoapods/prod/TVVLCKit-3.0-20260930-0854.tar.xz

The full application sources and build script are provided. Users can replace
and re-link the dynamic framework. The application does not restrict reverse
engineering for debugging modifications to this library.

The app icon is reused from the user's Private TV project. No channels or
third-party playlists are bundled.
