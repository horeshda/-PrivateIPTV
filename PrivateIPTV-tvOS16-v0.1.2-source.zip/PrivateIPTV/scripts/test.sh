#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
test_binary="$(mktemp -t privateiptv-tests.XXXXXX)"
trap 'rm -f "$test_binary"' EXIT HUP INT TERM
cc -std=c11 -Wall -Wextra -Werror -g -fsanitize=address,undefined Core/M3U.c tests/parser.c -o "$test_binary"
# LeakSanitizer cannot run under the container tracer; address/UB checks remain.
ASAN_OPTIONS=detect_leaks=0 "$test_binary"
if [ "$(uname -s)" = Darwin ]; then
    cc -fobjc-arc -fblocks -Wno-unused-parameter -Wno-deprecated-declarations \
       -framework Foundation Core/M3U.c tests/store.m -o "$test_binary"
    "$test_binary"
fi
