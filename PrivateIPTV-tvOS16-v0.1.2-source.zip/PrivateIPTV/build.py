#!/usr/bin/env python3
"""Build a tvOS 16 arm64 IPA on a macOS runner. No Apple account required.

Download the exact VideoLAN binary recorded by the TVVLCKit 3.7.4 podspec,
verify SHA-256, compile with Apple's SDK, embed and ad-hoc sign the framework,
compile the tvOS icon, then verify the IPA. TrollStore performs installation.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import plistlib
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.request
import zipfile
from scripts.compile_icon import compile_icon

ROOT = Path(__file__).resolve().parent
VLC_URL = 'https://download.videolan.org/cocoapods/prod/TVVLCKit-3.0-20260930-0854.tar.xz'
VLC_SHA256 = '07892cae8e59e95a23f1fcf11692f802eae106312aa5ad9782faa2556b2d65d5'

def run(*command):
    subprocess.run(command, check=True, cwd=ROOT)

def fetch_vlc(cache):
    cache.mkdir(parents=True, exist_ok=True)
    archive = cache / 'TVVLCKit-3.7.4.tar.xz'
    if not archive.exists() or hashlib.sha256(archive.read_bytes()).hexdigest() != VLC_SHA256:
        temporary = archive.with_suffix('.download')
        print('Downloading TVVLCKit 3.7.4 from VideoLAN', flush=True)
        with urllib.request.urlopen(VLC_URL, timeout=90) as response, temporary.open('wb') as output:
            shutil.copyfileobj(response, output)
        if hashlib.sha256(temporary.read_bytes()).hexdigest() != VLC_SHA256:
            temporary.unlink(missing_ok=True)
            raise RuntimeError('VideoLAN download checksum mismatch')
        temporary.replace(archive)
    unpacked = cache / 'TVVLCKit-3.7.4'
    # Always extract the verified archive, avoiding stale extracted dependencies.
    if unpacked.exists():
        shutil.rmtree(unpacked)
    unpacked.mkdir()
    with tarfile.open(archive) as tar:
        tar.extractall(unpacked, filter='data')
    xc = next(unpacked.rglob('TVVLCKit.xcframework'), None)
    if not xc:
        raise RuntimeError('VideoLAN archive contains no TVVLCKit.xcframework')
    info = plistlib.loads((xc / 'Info.plist').read_bytes())
    for item in info['AvailableLibraries']:
        if (item.get('SupportedPlatform') == 'tvos'
            and not item.get('SupportedPlatformVariant')
            and 'arm64' in item['SupportedArchitectures']):
            framework = xc / item['LibraryIdentifier'] / item['LibraryPath']
            if framework.exists():
                return framework, unpacked
    raise RuntimeError('No tvOS arm64 DEVICE framework found')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='dist/PrivateIPTV-tvOS16-v0.1.2.ipa')
    args = parser.parse_args()
    if sys.platform != 'darwin':
        raise SystemExit('Run this build on the included GitHub Actions macOS runner.')
    sdk = subprocess.check_output(['xcrun', '--sdk', 'appletvos', '--show-sdk-path'], text=True).strip()
    clang = subprocess.check_output(['xcrun', '--sdk', 'appletvos', '--find', 'clang'], text=True).strip()
    framework, dependency_root = fetch_vlc(ROOT / '.build-cache')
    # Execute the same parser used in the app, on the build host.
    run('sh', str(ROOT / 'scripts/test.sh'))
    output = Path(args.output).resolve(); output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='privateiptv-') as directory:
        staging = Path(directory)
        app = staging / 'Payload/PrivateIPTV.app'; app.mkdir(parents=True)
        flags = [clang, '-target', 'arm64-apple-tvos16.0', '-isysroot', sdk,
                 '-fobjc-arc', '-fblocks', '-O2', '-Wall', '-Wextra',
                 '-Werror=unguarded-availability', '-Werror=implicit-function-declaration',
                 '-Wno-unused-parameter', '-Wno-deprecated-declarations',
                 '-F', str(framework.parent)]
        sources = sorted((ROOT / 'Native').glob('*.m')) + [ROOT / 'Core/M3U.c']
        command = flags + [str(s) for s in sources]
        for name in ['UIKit', 'Foundation', 'TVVLCKit', 'QuartzCore', 'CoreGraphics',
                     'CoreText', 'AVFoundation', 'AudioToolbox', 'OpenGLES', 'VideoToolbox', 'CoreMedia']:
            command += ['-framework', name]
        command += ['-lc++', '-lxml2', '-lz', '-lbz2', '-liconv', '-lobjc',
                    '-Wl,-rpath,@executable_path/Frameworks', '-o', str(app / 'PrivateIPTV')]
        run(*command)
        # Run Clang's analyzer on every Objective-C source and fail on diagnostics.
        analyzer = staging / 'analysis'; analyzer.mkdir()
        for source in sources:
            if source.suffix != '.m':
                continue
            report = analyzer / (source.stem + '.plist')
            run(*flags, '--analyze', '-Xanalyzer', '-analyzer-output=plist', str(source), '-o', str(report))
            diagnostics = plistlib.loads(report.read_bytes()).get('diagnostics', []) if report.exists() else []
            if diagnostics:
                raise RuntimeError(f'Static analyzer diagnostics in {source.name}')
        os.chmod(app / 'PrivateIPTV', 0o755)
        embedded = app / 'Frameworks/TVVLCKit.framework'
        shutil.copytree(framework, embedded, symlinks=True)
        embedded_info = plistlib.loads((embedded / 'Info.plist').read_bytes())
        binary = embedded / embedded_info['CFBundleExecutable']
        archs = subprocess.check_output(['xcrun', 'lipo', '-archs', str(binary)], text=True).split()
        if archs != ['arm64']:
            thinned = binary.with_suffix('.arm64')
            run('xcrun', 'lipo', str(binary), '-thin', 'arm64', '-output', str(thinned)); thinned.replace(binary)
        os.chmod(binary, 0o755)
        for name in ['Headers', 'Modules', '_CodeSignature']:
            path = embedded / name
            if path.is_dir(): shutil.rmtree(path)
        for resource in (ROOT / 'Resources').iterdir():
            if resource.is_file(): shutil.copy2(resource, app / resource.name)
        acknowledgements = app / 'Acknowledgements'; acknowledgements.mkdir()
        shutil.copy2(ROOT / 'THIRD_PARTY.md', acknowledgements)
        licenses = list(dependency_root.rglob('COPYING*'))
        if not licenses:
            raise RuntimeError('VideoLAN archive is missing its license notice')
        for i, license_file in enumerate(licenses):
            if license_file.is_file(): shutil.copy2(license_file, acknowledgements / f'VideoLAN-{i}-{license_file.name}')
        info = plistlib.loads((ROOT / 'Info.plist').read_bytes()); info.update(compile_icon(app))
        (app / 'Info.plist').write_bytes(plistlib.dumps(info, fmt=plistlib.FMT_BINARY))
        (app / 'PkgInfo').write_bytes(b'APPL????')
        run('codesign', '--force', '--sign', '-', '--timestamp=none', str(embedded))
        run('codesign', '--force', '--sign', '-', '--timestamp=none', '--entitlements', str(ROOT / 'entitlements.plist'), str(app))
        run('codesign', '--verify', '--deep', '--strict', str(app))
        with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for path in sorted(app.rglob('*')):
                if path.is_file(): archive.write(path, path.relative_to(staging))
    run(sys.executable, str(ROOT / 'tests/verify_ipa.py'), str(output))
    report = {'app': 'Private IPTV', 'version': '0.1.2', 'minimum_tvOS': '16.0',
              'interface_language': 'en', 'appearance': ['Light', 'Dark', 'System'], 'icon': 'Turquoise and green television waves',
              'icon_source_sha256': hashlib.sha256((ROOT / 'Artwork/AppIcon-waves.png').read_bytes()).hexdigest(),
              'bundle_id': 'com.horesh.privateiptv.tvos', 'architecture': 'arm64',
              'player': 'TVVLCKit 3.7.4', 'signing': 'ad-hoc; install using TrollStore-tvOS',
              'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
              'passed': ['Native device compilation', 'Clang static analyzer', 'Parser tests',
                         'Compiled tvOS icon', 'codesign verification', 'IPA validation'],
              'not_tested': ['Physical Apple TV playback', 'Remote navigation on tvOS 16']}
    (output.parent / 'BUILD-REPORT.json').write_text(json.dumps(report, indent=2) + '\n')
    print(f'Built and verified: {output}')

if __name__ == '__main__':
    main()
