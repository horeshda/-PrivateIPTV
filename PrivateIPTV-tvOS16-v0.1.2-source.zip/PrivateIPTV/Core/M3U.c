#include "M3U.h"
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

static char *trim(char *s) {
    while (*s && isspace((unsigned char)*s)) s++;
    size_t n=strlen(s);
    while(n && isspace((unsigned char)s[n-1])) s[--n]=0;
    return s;
}
static char *duplicate(const char *s) {
    size_t n=strlen(s)+1; char *p=malloc(n); if(p)memcpy(p,s,n); return p;
}
static void clear(char **s) { free(*s); *s=NULL; }
static int assign(char **dst,const char *s) {
    char *p=duplicate(s); if(!p)return 0; clear(dst); *dst=p; return 1;
}
static char *attribute(const char *s,const char *key) {
    size_t k=strlen(key);
    while(*s) {
        while(*s && isspace((unsigned char)*s)) s++;
        const char *start=s;
        while(*s && !isspace((unsigned char)*s) && *s!='=')s++;
        size_t n=(size_t)(s-start);
        while(isspace((unsigned char)*s))s++;
        if(*s!='=')continue;
        s++; while(isspace((unsigned char)*s))s++;
        char quote=(*s=='"'||*s=='\'')?*s++:0;
        const char *value=s;
        while(*s && (quote?*s!=quote:!isspace((unsigned char)*s)))s++;
        size_t len=(size_t)(s-value);
        if(n==k && !strncmp(start,key,k)) {
            char *out=malloc(len+1); if(out){memcpy(out,value,len);out[len]=0;} return out;
        }
        if(quote&&*s)s++;
    }
    return NULL;
}
int m3u_parse(const char *text,size_t length,M3UCallback callback,void *context) {
    if(!text||!length||!callback)return M3U_EMPTY;
    if(length>32*1024*1024 || memchr(text,0,length))return M3U_LIMIT;
    char *buffer=malloc(length+1); if(!buffer)return M3U_MEMORY;
    memcpy(buffer,text,length);buffer[length]=0;
    char *start=buffer;
    if(length>=3 && !memcmp(start,"\xef\xbb\xbf",3))start+=3;
    /* An HLS manifest is one playable channel, never a list of segments. */
    for(char *p=start;*p;) {
        char *e=strpbrk(p,"\r\n");size_t n=e?(size_t)(e-p):strlen(p);
        size_t skip=0;while(skip<n && isspace((unsigned char)p[skip]))skip++;
        if(n-skip>=7&&!strncmp(p+skip,"#EXT-X-",7)){free(buffer);return M3U_HLS;}
        if(!e)break;
        p=e+1;
    }
    char *name=NULL,*group=NULL,*logo=NULL,*id=NULL,*ua=NULL,*ref=NULL;
    int result=M3U_EMPTY, pending=0;size_t count=0;
    for(char *p=start;*p;) {
        char *e=strpbrk(p,"\r\n"); if(e)*e=0;
        if(strlen(p)>65536){result=M3U_LIMIT;break;}
        char *line=trim(p);
        if(!strncmp(line,"#EXTINF:",8)) {
            clear(&name);clear(&group);clear(&logo);clear(&id);clear(&ua);clear(&ref);
            pending=1; char quote=0,*comma=NULL;
            for(char *s=line+8;*s;s++) {
                if(quote){if(*s==quote)quote=0;}
                else if(*s=='"'||*s=='\'')quote=*s;
                else if(*s==','){comma=s;break;}
            }
            if(comma){*comma=0;if(!assign(&name,trim(comma+1))){result=M3U_MEMORY;break;}}
            group=attribute(line+8,"group-title");logo=attribute(line+8,"tvg-logo");id=attribute(line+8,"tvg-id");
            if(!name||!*name){clear(&name);name=attribute(line+8,"tvg-name");}
        } else if(!strncmp(line,"#EXTGRP:",8)) {
            if(!assign(&group,trim(line+8))){result=M3U_MEMORY;break;}
        } else if(!strncmp(line,"#EXTVLCOPT:http-user-agent=",27)) {
            if(!assign(&ua,line+27)){result=M3U_MEMORY;break;}
        } else if(!strncmp(line,"#EXTVLCOPT:http-referrer=",25)) {
            if(!assign(&ref,line+25)){result=M3U_MEMORY;break;}
        } else if(*line && *line!='#') {
            int absolute=!strncmp(line,"https://",8)||!strncmp(line,"http://",7);
            if(pending||absolute) {
                if(++count>50000){result=M3U_LIMIT;break;}
                M3UEntry entry={name?name:"",group?group:"",logo?logo:"",id?id:"",line,ua?ua:"",ref?ref:""};
                if(!callback(&entry,context)){result=M3U_LIMIT;break;}
                result=M3U_OK;
            }
            pending=0;clear(&name);clear(&group);clear(&logo);clear(&id);clear(&ua);clear(&ref);
        }
        if(!e)break;
        p=e+1;
    }
    clear(&name);clear(&group);clear(&logo);clear(&id);clear(&ua);clear(&ref);free(buffer);
    return result;
}
