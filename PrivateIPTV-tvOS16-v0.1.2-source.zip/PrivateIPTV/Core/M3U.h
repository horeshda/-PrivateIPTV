#ifndef PRIVATE_IPTV_M3U_H
#define PRIVATE_IPTV_M3U_H
#include <stddef.h>
typedef struct {
    const char *name, *group, *logo, *tvg_id, *url, *user_agent, *referrer;
} M3UEntry;
typedef int (*M3UCallback)(const M3UEntry *, void *);
enum { M3U_OK=0, M3U_HLS=1, M3U_EMPTY=2, M3U_LIMIT=3, M3U_MEMORY=4 };
/* Input must be UTF-8 without embedded NULs. Callback strings live only during
   the call. A false callback return stops with M3U_LIMIT. No network I/O. */
int m3u_parse(const char *text, size_t length, M3UCallback callback, void *context);
#endif
