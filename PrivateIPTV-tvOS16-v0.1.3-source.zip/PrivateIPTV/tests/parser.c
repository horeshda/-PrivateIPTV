#include "../Core/M3U.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct {int n;char name[512],group[512],url[1024],ua[256],ref[256],logo[512],id[128];} Result;
static int collect(const M3UEntry *e,void *p){
    Result *r=p;r->n++;
    snprintf(r->name,sizeof(r->name),"%s",e->name);snprintf(r->group,sizeof(r->group),"%s",e->group);
    snprintf(r->url,sizeof(r->url),"%s",e->url);snprintf(r->ua,sizeof(r->ua),"%s",e->user_agent);
    snprintf(r->ref,sizeof(r->ref),"%s",e->referrer);snprintf(r->logo,sizeof(r->logo),"%s",e->logo);
    snprintf(r->id,sizeof(r->id),"%s",e->tvg_id);return 1;
}
static Result parse(const char *s,int expected){
    Result r={0};assert(m3u_parse(s,strlen(s),collect,&r)==expected);
    FILE *file=tmpfile();assert(file);assert(fwrite(s,1,strlen(s),file)==strlen(s));
    Result streamed={0};assert(m3u_parse_file(file,collect,&streamed)==expected);fclose(file);
    assert(!memcmp(&r,&streamed,sizeof(r)));return r;
}
static int stop_after_one(const M3UEntry *entry,void *raw){(void)entry;(*(int *)raw)++;return 0;}
static void large_playlists(void){
    const size_t capacity=100*1024*1024;char *text=malloc(capacity);assert(text);size_t used=0;
    for(size_t i=0;i<M3U_MAX_ENTRIES;i++){
        int n=snprintf(text+used,capacity-used,"#EXTINF:-1 group-title=\"Large catalog\" tvg-logo=\"https://example.org/logo.png\",Channel %zu\nhttps://example.org/live/%zu.ts\n",i,i);
        assert(n>0&&(size_t)n<capacity-used);used+=(size_t)n;
    }
    assert(used>32*1024*1024);Result result=parse(text,M3U_OK);assert((size_t)result.n==M3U_MAX_ENTRIES);
    assert(!strcmp(result.url,"https://example.org/live/499999.ts"));
    strcpy(text+used,"https://example.org/overflow.ts\n");result=parse(text,M3U_LIMIT);assert((size_t)result.n==M3U_MAX_ENTRIES);free(text);
    FILE *file=tmpfile();assert(file);
    char block[65536];memset(block,'x',sizeof(block));block[0]='#';block[sizeof(block)-1]='\n';
    for(size_t written=0;written<M3U_MAX_BYTES;written+=sizeof(block))assert(fwrite(block,1,sizeof(block),file)==sizeof(block));
    result=(Result){0};assert(m3u_parse_file(file,collect,&result)==M3U_EMPTY);assert(result.n==0);
    assert(fseek(file,0,SEEK_END)==0);assert(fputc('\n',file)!=EOF);
    assert(m3u_parse_file(file,collect,&result)==M3U_FILE_LIMIT);fclose(file);
    assert(m3u_parse("x",M3U_MAX_BYTES+1,collect,&result)==M3U_FILE_LIMIT);
    char *line=malloc(M3U_MAX_LINE+3);assert(line);memset(line,'x',M3U_MAX_LINE+1);line[0]='#';line[M3U_MAX_LINE+1]=0;
    parse(line,M3U_LINE_LIMIT);line[M3U_MAX_LINE]=0;parse(line,M3U_EMPTY);free(line);
    const char *two="https://example.org/1\nhttps://example.org/2";
    int stopped=0;assert(m3u_parse(two,strlen(two),stop_after_one,&stopped)==M3U_LIMIT);assert(stopped==1);
    assert(m3u_parse_file(NULL,collect,&result)==M3U_IO);
    puts("Large playlists: 500,000 entries (>32 MB), one-over-entry-limit, exact 256 MB, byte/line limits, callback cancellation and file/buffer parity passed.");
}
int main(void){
    Result r=parse("\xef\xbb\xbf#EXTM3U\r\n#EXTINF:-1 tvg-id=\"id-1\" group-title=\"News, Israel\" tvg-logo=\"/logo.png\",כאן 11\r\nhttps://example.org/live.m3u8?x=1&y=2\r\n",M3U_OK);
    assert(r.n==1&&!strcmp(r.name,"כאן 11")&&!strcmp(r.group,"News, Israel")&&!strcmp(r.id,"id-1"));
    assert(!strcmp(r.logo,"/logo.png")&&!strcmp(r.url,"https://example.org/live.m3u8?x=1&y=2"));
    r=parse("#EXTM3U\n#EXTINF:-1 group-title='A' tvg-name=\"Name\",\n#EXTGRP:Sports\n#EXTVLCOPT:http-user-agent=Example/1\n#EXTVLCOPT:http-referrer=https://example.org/\n../live/one.ts\n",M3U_OK);
    assert(!strcmp(r.name,"Name")&&!strcmp(r.group,"Sports")&&!strcmp(r.ua,"Example/1")&&!strcmp(r.ref,"https://example.org/"));
    r=parse("#EXTINF:-1,One\n#EXTVLCOPT:http-user-agent=A\nhttps://e.org/1\n#EXTINF:-1,Two\nhttps://e.org/2",M3U_OK);assert(r.n==2&&!r.ua[0]);
    r=parse("#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000\nvariant.m3u8",M3U_HLS);assert(r.n==0);
    r=parse("#EXTM3U\n#EXT-X-TARGETDURATION:6\n#EXTINF:6,\nsegment.ts",M3U_HLS);assert(r.n==0);
    r=parse("https://e.org/1\n\n# comment\nhttp://e.org/2",M3U_OK);assert(r.n==2);
    parse("<html>Unauthorized</html>",M3U_EMPTY);parse("",M3U_EMPTY);parse("#EXTM3U\n#EXTINF:-1,Missing",M3U_EMPTY);
    r=parse("#EXTINF:-1 group-title=\"A\",Movie, Part 2\nhttps://e.org/m.mp4|User-Agent=X%2FY",M3U_OK);assert(!strcmp(r.name,"Movie, Part 2"));
    char zero[]={ 'a',0,'b' };assert(m3u_parse(zero,3,collect,&r)==M3U_INVALID);
    FILE *invalid=tmpfile();assert(invalid);assert(fwrite(zero,1,sizeof(zero),invalid)==sizeof(zero));assert(m3u_parse_file(invalid,collect,&r)==M3U_INVALID);fclose(invalid);
    r=parse("#EXTM3U\r#EXTINF:-1,One\rhttps://e.org/1\r#EXTINF:-1,Two\rhttps://e.org/2",M3U_OK);assert(r.n==2);
    r=parse("#EXTM3U\n#EXTINF:5,\nhttps://e.org/segment.ts\n#EXT-X-ENDLIST",M3U_HLS);assert(r.n==0);
    const size_t large_capacity=2500000;
    char *large=malloc(large_capacity);assert(large);size_t used=0;
    for(int i=0;i<20000;i++){
        int written=snprintf(large+used,large_capacity-used,"#EXTINF:-1 group-title=\"G\",Channel %d\nhttps://e.org/%d\n",i,i);
        assert(written>=0&&(size_t)written<large_capacity-used);
        used+=(size_t)written;
    }
    r=parse(large,M3U_OK);assert(r.n==20000);free(large);
    unsigned seed=13;
    for(int i=0;i<2000;i++){
        char input[1024];for(size_t n=0;n<sizeof(input);n++){seed=seed*1664525u+1013904223u;input[n]=(char)(1+(seed%126));}
        r=(Result){0};(void)m3u_parse(input,sizeof(input),collect,&r);
    }
    puts("Parser: metadata, Hebrew, BOM, CRLF, headers, relative URLs, HLS detection, invalid input, 20,000 channels and fuzz smoke passed.");
    large_playlists();
    return 0;
}
