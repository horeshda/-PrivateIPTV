#import <Foundation/Foundation.h>
#import "../Native/PlaylistStore.m"
#include <assert.h>
static void large_store(void){@autoreleasepool{
    FILE *input=tmpfile();assert(input);
    for(size_t i=0;i<M3U_MAX_ENTRIES;i++)assert(fprintf(input,"#EXTINF:-1 group-title=\"Large catalog\",Channel %zu\nhttps://example.org/live/%zu.ts\n",i,i)>0);
    ParseContext *context=[ParseContext new];context.channels=[NSMutableArray new];context.seen=[NSMutableSet new];context.groupNames=[NSMutableDictionary new];
    context.base=[NSURL URLWithString:@"https://example.org/list.m3u"];context.sourceID=@"large-test-source";
    assert(m3u_parse_file(input,ChannelCallback,(__bridge void *)context)==M3U_OK);fclose(input);
    assert(context.channels.count==M3U_MAX_ENTRIES);
    assert([context.channels.lastObject[@"url"] isEqual:@"https://example.org/live/499999.ts"]);
    assert(context.channels.firstObject[@"group"]==context.channels.lastObject[@"group"]);
    NSDictionary *last=context.channels.lastObject;
    NSURL *cache=[NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:[NSUUID.UUID.UUIDString stringByAppendingString:@".json"]]];
    assert(WriteCache(context.channels,cache));
    context.channels=nil;context.seen=nil;context.groupNames=nil;
    NSInputStream *stream=[NSInputStream inputStreamWithURL:cache];[stream open];
    NSArray *restored=[NSJSONSerialization JSONObjectWithStream:stream options:0 error:nil];[stream close];
    assert(restored.count==M3U_MAX_ENTRIES);assert([restored.lastObject isEqual:last]);
    assert([NSFileManager.defaultManager removeItemAtURL:cache error:nil]);
    context.cancelled=YES;M3UEntry entry={"Cancelled","","","","https://example.org/skip","",""};
    assert(ChannelCallback(&entry,(__bridge void *)context)==0);
    assert([Text("caf\xe9") isEqual:@"café"]);
    puts("Foundation large catalog: 500,000 channels, shared groups, streaming cache save/reload, cancellation and legacy encoding passed.");
}}
int main(void){@autoreleasepool{
    NSURL *base=[NSURL URLWithString:@"https://example.org/path/list.m3u"];
    M3UEntry entry={"כאן 11","חדשות","../logo.png","11","../live/11.m3u8|User-Agent=My%20Player&Referer=https%3A%2F%2Fexample.org%2F","",""};
    NSDictionary *c=ParseChannel(&entry,base,@"test-source");
    assert([c[@"url"] isEqual:@"https://example.org/live/11.m3u8"]);
    assert([c[@"logo"] isEqual:@"https://example.org/logo.png"]);
    assert([c[@"headers"][@"User-Agent"] isEqual:@"My Player"]);
    assert([c[@"headers"][@"Referer"] isEqual:@"https://example.org/"]);
    assert([c[@"name"] isEqual:@"כאן 11"]);
    assert([c[@"id"] isEqual:ParseChannel(&entry,base,@"test-source")[@"id"]]);
    assert(![c[@"id"] isEqual:ParseChannel(&entry,base,@"other-source")[@"id"]]);
    entry.url="file:///private/data";assert(!ParseChannel(&entry,base,@"s"));
    entry.url="javascript:alert(1)";assert(!ParseChannel(&entry,base,@"s"));
    entry.url="https://example.org/live.ts|User-Agent=x%0D%0Ay";
    c=ParseChannel(&entry,base,@"s");assert(!c[@"headers"][@"User-Agent"]);
    assert([PlaylistStore URLFromText:@" https://example.org/get.php?u=a&p=b&type=m3u_plus \n"]);
    assert(![PlaylistStore URLFromText:@"https://example.org/bad url"]);
    assert(![PlaylistStore URLFromText:@"file:///tmp/test"]);
    assert(![PlaylistStore URLFromText:(id)@123]);
    large_store();
    puts("Foundation adapter: relative URLs, Hebrew, HTTP headers, stable IDs and URL validation passed.");
}return 0;}
