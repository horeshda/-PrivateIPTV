#import "PlaylistStore.h"
#import <CommonCrypto/CommonDigest.h>
#import "../Core/M3U.h"

static NSString *const StateKey=@"PrivateIPTV.library.v1";
static NSString *Text(const char *p){
    if(!p)return @"";
    return [NSString stringWithUTF8String:p]?:[[NSString alloc]initWithBytes:p length:strlen(p) encoding:NSWindowsCP1252StringEncoding]?:@"";
}
static BOOL WriteCache(NSArray *channels,NSURL *url){
    NSOutputStream *stream=[NSOutputStream outputStreamWithURL:url append:NO];[stream open];
    if(stream.streamStatus!=NSStreamStatusOpen){[stream close];return NO;}
    NSInteger written=[NSJSONSerialization writeJSONObject:channels toStream:stream options:0 error:nil];
    BOOL success=written>0&&!stream.streamError;[stream close];return success;
}
static NSString *Hash(NSString *s){
    NSData *data=[s dataUsingEncoding:NSUTF8StringEncoding];unsigned char bytes[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(data.bytes,(CC_LONG)data.length,bytes);NSMutableString *r=[NSMutableString new];
    for(NSUInteger i=0;i<sizeof(bytes);i++)[r appendFormat:@"%02x",bytes[i]];return r;
}
static NSString *Resolve(NSString *s,NSURL *base){
    NSURL *u=[NSURL URLWithString:s relativeToURL:base].absoluteURL;
    return [@[@"http",@"https"] containsObject:u.scheme.lowercaseString]&&u.host.length?u.absoluteString:nil;
}
static NSDictionary *ParseChannel(const M3UEntry *e,NSURL *base,NSString *sid){
    NSString *line=Text(e->url);NSMutableDictionary *headers=[NSMutableDictionary new];
    if(strlen(e->user_agent))headers[@"User-Agent"]=Text(e->user_agent);
    if(strlen(e->referrer))headers[@"Referer"]=Text(e->referrer);
    NSRange pipe=[line rangeOfString:@"|"];
    if(pipe.location!=NSNotFound){
        NSString *suffix=[line substringFromIndex:pipe.location+1];line=[line substringToIndex:pipe.location];
        for(NSString *pair in [suffix componentsSeparatedByString:@"&"]){
            NSRange eq=[pair rangeOfString:@"="];if(eq.location==NSNotFound)continue;
            NSString *key=[[pair substringToIndex:eq.location] lowercaseString];
            NSString *value=[[pair substringFromIndex:eq.location+1] stringByRemovingPercentEncoding];
            if(!value||[value rangeOfCharacterFromSet:NSCharacterSet.newlineCharacterSet].location!=NSNotFound)continue;
            if([key isEqual:@"user-agent"])headers[@"User-Agent"]=value;
            if([key isEqual:@"referer"]||[key isEqual:@"referrer"])headers[@"Referer"]=value;
        }
    }
    NSString *url=Resolve(line,base);if(!url)return nil;
    NSString *name=Text(e->name);if(!name.length)name=[NSURL URLWithString:url].lastPathComponent;
    if(!name.length)name=@"Channel";
    NSString *group=Text(e->group);if(!group.length)group=@"General";
    NSString *logo=strlen(e->logo)?Resolve(Text(e->logo),base):nil;
    // Full URL prevents tvg-id collisions across SD/HD variants. Refresh order
    // changes preserve favorites. Provider token changes may produce new IDs.
    NSString *identifier=Hash([sid stringByAppendingFormat:@"|%@",url]);
    return @{@"id":identifier,@"source":sid,@"name":name,@"group":group,@"logo":logo?:@"",@"url":url,@"headers":headers};
}
@interface ParseContext:NSObject
@property(nonatomic,strong) NSMutableArray *channels;
@property(nonatomic,strong) NSMutableSet *seen;
@property(nonatomic,strong) NSMutableDictionary *groupNames;
@property(nonatomic,strong) NSURL *base;
@property(nonatomic,copy) NSString *sourceID;
@property(atomic) BOOL cancelled;
@end
@implementation ParseContext @end
static int ChannelCallback(const M3UEntry *e,void *raw){
    @autoreleasepool {
        ParseContext *c=(__bridge ParseContext *)raw;
        if(c.cancelled)return 0;
        NSDictionary *channel=ParseChannel(e,c.base,c.sourceID);
        if(channel&&![c.seen containsObject:channel[@"id"]]){
            NSString *group=channel[@"group"],*shared=c.groupNames[group];
            if(shared){NSMutableDictionary *pooled=[channel mutableCopy];pooled[@"group"]=shared;channel=[pooled copy];}
            else c.groupNames[group]=group;
            [c.channels addObject:channel];[c.seen addObject:channel[@"id"]];
        }
    }return 1;
}
@interface PlaylistStore ()
@property(nonatomic,strong) NSMutableArray *mutableSources;
@property(nonatomic,strong) NSMutableDictionary *mutableCatalog;
@property(nonatomic,strong) NSMutableSet *mutableFavorites;
@property(nonatomic,strong) NSMutableDictionary<NSUUID *,NSURLSessionTask *> *tasks;
@property(nonatomic,strong) NSMutableDictionary<NSString *,NSUUID *> *revisions;
@property(nonatomic,strong) NSMutableDictionary<NSUUID *,ParseContext *> *parses;
@property(nonatomic,strong) NSURLSession *session;
@property(nonatomic,strong) NSURL *cacheDirectory;
@end
@implementation PlaylistStore
- (instancetype)init {
    if((self=[super init])){
        _mutableSources=[NSMutableArray new];_mutableCatalog=[NSMutableDictionary new];_mutableFavorites=[NSMutableSet new];
        _tasks=[NSMutableDictionary new];_revisions=[NSMutableDictionary new];_parses=[NSMutableDictionary new];
        NSURLSessionConfiguration *cfg=NSURLSessionConfiguration.ephemeralSessionConfiguration;
        cfg.timeoutIntervalForRequest=60;cfg.timeoutIntervalForResource=300;cfg.HTTPMaximumConnectionsPerHost=3;
        NSOperationQueue *downloads=[NSOperationQueue new];downloads.maxConcurrentOperationCount=1;
        _session=[NSURLSession sessionWithConfiguration:cfg delegate:nil delegateQueue:downloads];
        NSURL *caches=[NSFileManager.defaultManager URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask].firstObject;
        _cacheDirectory=[caches URLByAppendingPathComponent:@"PrivateIPTV" isDirectory:YES];
        [NSFileManager.defaultManager createDirectoryAtURL:_cacheDirectory withIntermediateDirectories:YES attributes:nil error:nil];
        NSDictionary *saved=[NSUserDefaults.standardUserDefaults dictionaryForKey:StateKey];
        id fav=saved[@"favorites"];if([fav isKindOfClass:NSArray.class])for(id v in fav)if([v isKindOfClass:NSString.class])[_mutableFavorites addObject:v];
        id list=saved[@"sources"];
        if([list isKindOfClass:NSArray.class])for(id source in list){
            if(![source isKindOfClass:NSDictionary.class]||![source[@"name"] isKindOfClass:NSString.class]||![source[@"id"] isKindOfClass:NSString.class]||![[NSUUID alloc]initWithUUIDString:source[@"id"]]||![PlaylistStore URLFromText:source[@"url"]])continue;
            [_mutableSources addObject:source];
        }
    }return self;
}
+ (NSURL *)URLFromText:(NSString *)text {
    if(![text isKindOfClass:NSString.class])return nil;
    NSString *t=[text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    if(!t.length||t.length>16384||[t rangeOfCharacterFromSet:NSCharacterSet.whitespaceAndNewlineCharacterSet].location!=NSNotFound)return nil;
    NSURL *u=[NSURL URLWithString:t];return [@[@"http",@"https"] containsObject:u.scheme.lowercaseString]&&u.host.length?u:nil;
}
- (NSArray *)sources{return [self.mutableSources copy];}
- (NSDictionary *)catalog{return [self.mutableCatalog copy];}
- (NSSet *)favorites{return [self.mutableFavorites copy];}
- (NSURL *)cacheURL:(NSString *)sid{return [self.cacheDirectory URLByAppendingPathComponent:[sid stringByAppendingString:@".json"]];}
- (void)restoreCachesWithCompletion:(void (^)(void))completion {
    NSArray *sources=self.sources;NSURL *directory=self.cacheDirectory;__weak PlaylistStore *weakSelf=self;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0), ^{
        for(NSDictionary *source in sources){@autoreleasepool{
            NSURL *url=[directory URLByAppendingPathComponent:[source[@"id"] stringByAppendingString:@".json"]];
            NSInputStream *stream=[NSInputStream inputStreamWithURL:url];[stream open];
            if(stream.streamStatus!=NSStreamStatusOpen){[stream close];continue;}
            id channels=[NSJSONSerialization JSONObjectWithStream:stream options:0 error:nil];[stream close];
            if(![channels isKindOfClass:NSArray.class]||[channels count]>M3U_MAX_ENTRIES)continue;
            NSMutableArray *valid=[NSMutableArray new];
            for(id c in channels){@autoreleasepool{
                if(![c isKindOfClass:NSDictionary.class])continue;
                BOOL good=YES;for(NSString *key in @[@"id",@"source",@"name",@"group",@"logo",@"url"])if(![c[key] isKindOfClass:NSString.class])good=NO;
                if(good&&[PlaylistStore URLFromText:c[@"url"]]&&[c[@"headers"] isKindOfClass:NSDictionary.class])[valid addObject:c];
            }}
            dispatch_async(dispatch_get_main_queue(), ^{
                PlaylistStore *s=weakSelf;NSString *sid=source[@"id"];
                if(!s||s.revisions[sid]||s.mutableCatalog[sid]||![s.mutableSources containsObject:source])return;
                s.mutableCatalog[sid]=valid;if(s.changed)s.changed();
            });
        }}
        dispatch_async(dispatch_get_main_queue(),completion);
    });
}
- (void)save {
    [NSUserDefaults.standardUserDefaults setObject:@{@"sources":self.mutableSources,@"favorites":self.mutableFavorites.allObjects} forKey:StateKey];
    if(self.changed)self.changed();
}
- (NSUUID *)loadName:(NSString *)name url:(NSURL *)url sourceID:(NSString *)sourceID completion:(void (^)(NSString *))completion {
    NSAssert(NSThread.isMainThread,@"Store operations run on main");
    NSString *sid=sourceID?:NSUUID.UUID.UUIDString;
    NSUUID *old=self.revisions[sid];if(old)[self cancel:old];
    NSUUID *request=NSUUID.UUID;self.revisions[sid]=request;
    ParseContext *context=[ParseContext new];self.parses[request]=context;
    NSURL *temporary=[self.cacheDirectory URLByAppendingPathComponent:[request.UUIDString stringByAppendingString:@".tmp"]];
    __weak PlaylistStore *weakSelf=self;
    NSURLSessionDownloadTask *task=[self.session downloadTaskWithURL:url completionHandler:^(NSURL *file,NSURLResponse *response,NSError *error){
        NSString *message=nil;context.channels=[NSMutableArray new];context.seen=[NSMutableSet new];context.groupNames=[NSMutableDictionary new];context.base=response.URL?:url;context.sourceID=sid;
        NSInteger status=[response isKindOfClass:NSHTTPURLResponse.class]?[(NSHTTPURLResponse *)response statusCode]:0;
        if(error)message=@"Download failed. Check your connection and playlist URL.";
        else if(status<200||status>=300)message=[NSString stringWithFormat:@"The playlist server returned error %ld.",(long)status];
        else {
            NSNumber *size=nil;[file getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
            if(size.unsignedLongLongValue>M3U_MAX_BYTES)message=@"The playlist exceeds 256 MB. Use a smaller or live-TV-only list.";
            else {
                FILE *input=fopen(file.path.fileSystemRepresentation,"rb");
                if(!input)message=@"Could not read the downloaded playlist. Try again.";
                else {
                    int result=m3u_parse_file(input,ChannelCallback,(__bridge void *)context);fclose(input);
                    if(result==M3U_HLS){M3UEntry entry={name.UTF8String,"","","",url.absoluteString.UTF8String,"",""};ChannelCallback(&entry,(__bridge void *)context);}
                    else if(result==M3U_LIMIT)message=@"The playlist exceeds 500,000 entries. Use a smaller or live-TV-only list.";
                    else if(result==M3U_FILE_LIMIT)message=@"The playlist exceeds 256 MB. Use a smaller or live-TV-only list.";
                    else if(result==M3U_LINE_LIMIT)message=@"The playlist contains a line longer than 64 KB. Check the playlist format.";
                    else if(result==M3U_INVALID)message=@"Unsupported playlist encoding. Save it as UTF-8.";
                    else if(result==M3U_IO)message=@"Could not read the downloaded playlist. Try again.";
                    else if(result==M3U_MEMORY)message=@"Not enough memory to load the playlist.";
                    if(!message&&!context.channels.count)message=@"No HTTP/HTTPS channels found. Check that the URL points to an M3U playlist.";
                }
            }
        }
        context.seen=nil;context.groupNames=nil;
        // Serialize off the main thread, then atomically swap the completed cache.
        // Never replace the previous playlist with a partial or failed import.
        if(!message&&!context.cancelled&&!WriteCache(context.channels,temporary))message=@"Could not save the playlist. Check available storage and try again.";
        if(message||context.cancelled){context.channels=nil;[NSFileManager.defaultManager removeItemAtURL:temporary error:nil];}
        dispatch_async(dispatch_get_main_queue(), ^{
            PlaylistStore *s=weakSelf;
            if(!s||![s.revisions[sid] isEqual:request]){[NSFileManager.defaultManager removeItemAtURL:temporary error:nil];return;}
            [s.tasks removeObjectForKey:request];[s.revisions removeObjectForKey:sid];[s.parses removeObjectForKey:request];
            NSString *finalMessage=message;
            if(!finalMessage&&rename(temporary.path.fileSystemRepresentation,[s cacheURL:sid].path.fileSystemRepresentation))finalMessage=@"Could not save the playlist. Check available storage and try again.";
            if(!finalMessage){
                NSUInteger index=[s.mutableSources indexOfObjectPassingTest:^BOOL(NSDictionary *v,NSUInteger i,BOOL *stop){return [v[@"id"] isEqual:sid];}];
                NSDictionary *record=@{@"id":sid,@"name":name.length?name:@"My playlist",@"url":url.absoluteString};
                if(index==NSNotFound)[s.mutableSources addObject:record];else s.mutableSources[index]=record;
                s.mutableCatalog[sid]=context.channels;
                [s save];
            }
            [NSFileManager.defaultManager removeItemAtURL:temporary error:nil];completion(finalMessage);
        });
    }];
    self.tasks[request]=task;[task resume];return request;
}
- (void)cancel:(NSUUID *)request {
    self.parses[request].cancelled=YES;[self.parses removeObjectForKey:request];
    [self.tasks[request] cancel];[self.tasks removeObjectForKey:request];
    for(NSString *sid in [self.revisions.allKeys copy])if([self.revisions[sid] isEqual:request])[self.revisions removeObjectForKey:sid];
}
- (void)removeSource:(NSString *)sid {
    NSUUID *request=self.revisions[sid];if(request)[self cancel:request];
    for(NSDictionary *c in self.mutableCatalog[sid])[self.mutableFavorites removeObject:c[@"id"]];
    NSIndexSet *indices=[self.mutableSources indexesOfObjectsPassingTest:^BOOL(NSDictionary *v,NSUInteger i,BOOL *stop){return [v[@"id"] isEqual:sid];}];
    [self.mutableSources removeObjectsAtIndexes:indices];[self.mutableCatalog removeObjectForKey:sid];
    [NSFileManager.defaultManager removeItemAtURL:[self cacheURL:sid] error:nil];[self save];
}
- (void)toggleFavorite:(NSString *)identifier {
    if([self.mutableFavorites containsObject:identifier])[self.mutableFavorites removeObject:identifier];else [self.mutableFavorites addObject:identifier];[self save];
}
@end
