#ifndef PRIVATE_IPTV_M3U_H
#define PRIVATE_IPTV_M3U_H
#include <stddef.h>
#include <stdio.h>
#define M3U_MAX_BYTES ((size_t)256 * 1024 * 1024)
#define M3U_MAX_ENTRIES ((size_t)500000)
#define M3U_MAX_LINE ((size_t)65536)
typedef struct {
    const char *name, *group, *logo, *tvg_id, *url, *user_agent, *referrer;
} M3UEntry;
typedef int (*M3UCallback)(const M3UEntry *, void *);
enum { M3U_OK=0, M3U_HLS=1, M3U_EMPTY=2, M3U_LIMIT=3, M3U_MEMORY=4,
       M3U_FILE_LIMIT=5, M3U_LINE_LIMIT=6, M3U_INVALID=7, M3U_IO=8 };
/* Input must be UTF-8 without embedded NULs. Callback strings live only during
   the call. A false callback return stops with M3U_LIMIT. No network I/O. */
int m3u_parse(const char *text, size_t length, M3UCallback callback, void *context);
/* Reads a seekable file from its beginning with bounded working memory.
   The caller retains ownership of the file. Same results as m3u_parse. */
int m3u_parse_file(FILE *file, M3UCallback callback, void *context);
#endif
