#include "M3U.h"
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

static char *trim(char *s) {
    while (*s && isspace((unsigned char)*s)) s++;
    size_t n=strlen(s);
    while(n && isspace((unsigned char)s[n-1])) s[--n]=0;
    return s;
}
static char *duplicate(const char *s) {
    size_t n=strlen(s)+1; char *p=malloc(n); if(p)memcpy(p,s,n); return p;
}
static void clear(char **s) { free(*s); *s=NULL; }
static int assign(char **dst,const char *s) {
    char *p=duplicate(s); if(!p)return 0; clear(dst); *dst=p; return 1;
}
static char *attribute(const char *s,const char *key) {
    size_t k=strlen(key);
    while(*s) {
        while(*s && isspace((unsigned char)*s)) s++;
        const char *start=s;
        while(*s && !isspace((unsigned char)*s) && *s!='=')s++;
        size_t n=(size_t)(s-start);
        while(isspace((unsigned char)*s))s++;
        if(*s!='=')continue;
        s++; while(isspace((unsigned char)*s))s++;
        char quote=(*s=='"'||*s=='\'')?*s++:0;
        const char *value=s;
        while(*s && (quote?*s!=quote:!isspace((unsigned char)*s)))s++;
        size_t len=(size_t)(s-value);
        if(n==k && !strncmp(start,key,k)) {
            char *out=malloc(len+1); if(out){memcpy(out,value,len);out[len]=0;} return out;
        }
        if(quote&&*s)s++;
    }
    return NULL;
}
/* Both input paths use a bounded line buffer; never duplicate the playlist. */
typedef struct {
    const unsigned char *text;
    size_t length, position, chunk_position, chunk_length;
    FILE *file;
    unsigned char chunk[8192];
    int error;
} Reader;
static int next_byte(Reader *r) {
    int byte;
    if(r->file) {
        if(r->chunk_position==r->chunk_length) {
            r->chunk_length=fread(r->chunk,1,sizeof(r->chunk),r->file);r->chunk_position=0;
            if(!r->chunk_length){if(ferror(r->file))r->error=M3U_IO;return EOF;}
        }
        byte=r->chunk[r->chunk_position++];
    }else {
        if(r->position==r->length)return EOF;
        byte=r->text[r->position];
    }
    if(++r->position>M3U_MAX_BYTES){r->error=M3U_FILE_LIMIT;return EOF;}
    if(!byte){r->error=M3U_INVALID;return EOF;}
    return byte;
}
static int next_line(Reader *r,char *line) {
    size_t n=0;int byte;
    while((byte=next_byte(r))!=EOF) {
        if(byte=='\n'||byte=='\r'){line[n]=0;return 1;}
        if(n==M3U_MAX_LINE){r->error=M3U_LINE_LIMIT;return 0;}
        line[n++]=(char)byte;
    }
    line[n]=0;return !r->error&&n>0;
}
static int rewind_reader(Reader *r) {
    r->position=r->chunk_position=r->chunk_length=0;r->error=0;
    if(r->file&&fseek(r->file,0,SEEK_SET)){r->error=M3U_IO;return 0;}
    return 1;
}
static char *content_line(char *line,int first) {
    if(first&&strlen(line)>=3&&!memcmp(line,"\xef\xbb\xbf",3))line+=3;
    return trim(line);
}
static int parse_reader(Reader *reader,M3UCallback callback,void *context) {
    char *buffer=malloc(M3U_MAX_LINE+1);if(!buffer)return M3U_MEMORY;
    /* Scan before callbacks: a late HLS tag still denotes a single stream. */
    int hls=0,first=1;
    while(next_line(reader,buffer)) {
        char *line=content_line(buffer,first);first=0;
        if(!strncmp(line,"#EXT-X-",7))hls=1;
    }
    if(reader->error){int error=reader->error;free(buffer);return error;}
    if(hls){free(buffer);return M3U_HLS;}
    if(!rewind_reader(reader)){free(buffer);return M3U_IO;}
    char *name=NULL,*group=NULL,*logo=NULL,*id=NULL,*ua=NULL,*ref=NULL;
    int result=M3U_EMPTY, pending=0;size_t count=0;
    first=1;
    while(next_line(reader,buffer)) {
        char *line=content_line(buffer,first);first=0;
        if(!strncmp(line,"#EXTINF:",8)) {
            clear(&name);clear(&group);clear(&logo);clear(&id);clear(&ua);clear(&ref);
            pending=1; char quote=0,*comma=NULL;
            for(char *s=line+8;*s;s++) {
                if(quote){if(*s==quote)quote=0;}
                else if(*s=='"'||*s=='\'')quote=*s;
                else if(*s==','){comma=s;break;}
            }
            if(comma){*comma=0;if(!assign(&name,trim(comma+1))){result=M3U_MEMORY;break;}}
            group=attribute(line+8,"group-title");logo=attribute(line+8,"tvg-logo");id=attribute(line+8,"tvg-id");
            if(!name||!*name){clear(&name);name=attribute(line+8,"tvg-name");}
        } else if(!strncmp(line,"#EXTGRP:",8)) {
            if(!assign(&group,trim(line+8))){result=M3U_MEMORY;break;}
        } else if(!strncmp(line,"#EXTVLCOPT:http-user-agent=",27)) {
            if(!assign(&ua,line+27)){result=M3U_MEMORY;break;}
        } else if(!strncmp(line,"#EXTVLCOPT:http-referrer=",25)) {
            if(!assign(&ref,line+25)){result=M3U_MEMORY;break;}
        } else if(*line && *line!='#') {
            int absolute=!strncmp(line,"https://",8)||!strncmp(line,"http://",7);
            if(pending||absolute) {
                if(++count>M3U_MAX_ENTRIES){result=M3U_LIMIT;break;}
                M3UEntry entry={name?name:"",group?group:"",logo?logo:"",id?id:"",line,ua?ua:"",ref?ref:""};
                if(!callback(&entry,context)){result=M3U_LIMIT;break;}
                result=M3U_OK;
            }
            pending=0;clear(&name);clear(&group);clear(&logo);clear(&id);clear(&ua);clear(&ref);
        }
    }
    if(reader->error)result=reader->error;
    clear(&name);clear(&group);clear(&logo);clear(&id);clear(&ua);clear(&ref);free(buffer);
    return result;
}

int m3u_parse(const char *text,size_t length,M3UCallback callback,void *context) {
    if(!text||!length||!callback)return M3U_EMPTY;
    if(length>M3U_MAX_BYTES)return M3U_FILE_LIMIT;
    Reader reader={0};reader.text=(const unsigned char *)text;reader.length=length;
    return parse_reader(&reader,callback,context);
}
int m3u_parse_file(FILE *file,M3UCallback callback,void *context) {
    if(!file||!callback)return M3U_IO;
    if(fseek(file,0,SEEK_END))return M3U_IO;
    long length=ftell(file);if(length<0)return M3U_IO;
    if((unsigned long)length>M3U_MAX_BYTES)return M3U_FILE_LIMIT;
    Reader reader={0};reader.file=file;
    if(!rewind_reader(&reader))return M3U_IO;
    return parse_reader(&reader,callback,context);
}
