#import <UIKit/UIKit.h>
#import "../Native/LibraryScreen.h"
#import "../Native/PlayerScreen.h"
#import "../Native/PlaylistStore.h"
#import "../Native/PlayerMenu.h"

@interface LibraryScreen(Testing)
- (void)reload;
@end
@interface PlayerScreen(Testing)
- (void)close;
- (void)next;
- (void)favorite;
- (void)hideControls;
- (void)showControls;
- (void)togglePause;
@end
@interface TestApp:NSObject<UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) LibraryScreen *library;
@property(nonatomic) NSUInteger cycle;
@property(nonatomic) NSUInteger checks;
@property(nonatomic) NSUInteger returnChecks;
@property(atomic) NSUInteger heartbeat;
@property(nonatomic,strong) NSTimer *pulse;
@property(nonatomic,strong) dispatch_source_t guard;
@end
@implementation TestApp
- (void)finish:(NSString *)error {
    NSString *message=error?[@"FAIL: " stringByAppendingString:error]:@"PASS: 6 real TVVLCKit H.264/AAC/subtitle playback returns; all four sizes selected through CC menu; audio menu; pause/resume; next channel; favorite updates; hidden controls; restored library focus; main-thread heartbeat.";
    [message writeToFile:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents/playback-ui-result.txt"] atomically:YES encoding:NSUTF8StringEncoding error:nil];
    puts(message.UTF8String);fflush(stdout);exit(error?1:0);
}
- (void)later:(double)seconds action:(void (^)(void))action {dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(seconds*NSEC_PER_SEC)),dispatch_get_main_queue(),action);}
- (BOOL)application:(UIApplication *)app didFinishLaunchingWithOptions:(NSDictionary *)options {
    [NSUserDefaults.standardUserDefaults removeObjectForKey:@"PrivateIPTV.library.v1"];
    [NSUserDefaults.standardUserDefaults removeObjectForKey:@"PrivateIPTV.subtitles.size"];
    self.pulse=[NSTimer scheduledTimerWithTimeInterval:.1 repeats:YES block:^(NSTimer *t){self.heartbeat++;}];
    self.guard=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0));
    dispatch_source_set_timer(self.guard,dispatch_time(DISPATCH_TIME_NOW,10*NSEC_PER_SEC),8*NSEC_PER_SEC,NSEC_PER_SEC);
    __block NSUInteger last=0;
    dispatch_source_set_event_handler(self.guard,^{NSUInteger beat=self.heartbeat;if(beat==last)[self finish:@"UI thread blocked for eight seconds"];last=beat;});dispatch_resume(self.guard);
    self.library=[LibraryScreen new];self.window=[[UIWindow alloc]initWithFrame:UIScreen.mainScreen.bounds];self.window.rootViewController=self.library;[self.window makeKeyAndVisible];
    [self later:1 action:^{[self seed];}];return YES;
}
- (void)seed {
    PlaylistStore *store=[self.library valueForKey:@"store"];NSString *sid=NSUUID.UUID.UUIDString;
    NSURL *fixture=[NSBundle.mainBundle URLForResource:@"playback" withExtension:@"mp4"];
    if(!fixture){[self finish:@"missing fixture"];return;}
    NSMutableArray *channels=[NSMutableArray new];
    for(NSUInteger i=0;i<30;i++)[channels addObject:@{@"id":[NSString stringWithFormat:@"test-%lu",(unsigned long)i],@"source":sid,@"name":[NSString stringWithFormat:@"Channel %lu",(unsigned long)i],@"group":@"Test",@"logo":@"",@"url":fixture.absoluteString,@"headers":@{}}];
    [[store valueForKey:@"mutableSources"] addObject:@{@"id":sid,@"name":@"Test",@"url":@"https://example.org/test.m3u"}];
    [store valueForKey:@"mutableCatalog"][sid]=channels;[self.library reload];
    [self later:1 action:^{[self openPlayer];}];
}
- (PlayerScreen *)player {return (PlayerScreen *)self.library.presentedViewController;}
- (void)openPlayer {
    if(self.cycle==6){[self finish:nil];return;}
    printf("REAL VLC cycle %lu\n",(unsigned long)self.cycle);fflush(stdout);
    UICollectionView *grid=[self.library valueForKey:@"grid"];
    [grid.delegate collectionView:grid didSelectItemAtIndexPath:[NSIndexPath indexPathForItem:8+self.cycle inSection:0]];
    self.checks=0;[self later:1 action:^{[self awaitPlaying:NO];}];
}
- (void)awaitPlaying:(BOOL)afterNext {
    PlayerScreen *p=[self player];NSDictionary *snapshot=[p valueForKey:@"snapshot"];
    if([snapshot[@"state"] isEqual:@"playing"]&&[snapshot[@"time"] intValue]>250){
        if(afterNext)[self prepareReturn];else [self enableCaptions];return;
    }
    if(++self.checks>30){[self finish:[NSString stringWithFormat:@"real playback did not progress: %@",snapshot]];return;}
    [self later:.5 action:^{[self awaitPlaying:afterNext];}];
}
- (void)selectRow:(NSUInteger)row {
    IPTVPlayerMenu *menu=[[self player] valueForKey:@"menu"];
    if(!menu||row>=[menu.table numberOfRowsInSection:0]){[self finish:@"menu row missing"];return;}
    id focus=[UIFocusSystem focusSystemForEnvironment:menu.view].focusedItem;
    if(![(UIView *)focus isDescendantOfView:menu.view]){[self finish:[NSString stringWithFormat:@"menu has no focus: %@",focus]];return;}
    [menu.table.delegate tableView:menu.table didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:row inSection:0]];
}
- (void)enableCaptions {
    NSDictionary *snapshot=[[self player] valueForKey:@"snapshot"];
    if([snapshot[@"subIDs"] count]<2){[self finish:@"real subtitle track missing"];return;}
    UIStackView *controls=[[self player] valueForKey:@"controls"];
    [(UIButton *)controls.arrangedSubviews[5] sendActionsForControlEvents:UIControlEventPrimaryActionTriggered];
    [self later:.2 action:^{
        [self selectRow:2]; // Enable the real English mov_text track.
        [self later:.8 action:^{
            NSDictionary *updated=[[self player] valueForKey:@"snapshot"];
            if([updated[@"subtitle"] intValue]<0){[self finish:@"subtitle selection did not reach decoder"];return;}
            [self chooseSize:0];
        }];
    }];
}
- (void)chooseSize:(NSUInteger)size {
    PlayerScreen *p=[self player];UIStackView *controls=[p valueForKey:@"controls"];
    [p showControls];[(UIButton *)controls.arrangedSubviews[5] sendActionsForControlEvents:UIControlEventPrimaryActionTriggered];
    [self later:.2 action:^{
        [self selectRow:0]; // CC -> Text size, exercising the real menu transition.
        [self later:.2 action:^{
            [self selectRow:size];
            [self later:.5 action:^{
                NSNumber *expected=@[@48,@32,@24,@16][size];
                if(![[NSUserDefaults.standardUserDefaults objectForKey:@"PrivateIPTV.subtitles.size"] isEqual:expected]){[self finish:@"size choice not saved"];return;}
                NSDictionary *snapshot=[[self player] valueForKey:@"snapshot"];
                if(![snapshot[@"canResize"] boolValue]||![snapshot[@"fontSize"] isEqual:expected]){[self finish:@"real decoder did not receive size"];return;}
                if([[self player] valueForKey:@"menu"]){[self finish:@"menu did not close"];return;}
                if(size<3)[self chooseSize:size+1];else [self exercisePlayer];
            }];
        }];
    }];
}
- (void)exercisePlayer {
    PlayerScreen *p=[self player];UIStackView *controls=[p valueForKey:@"controls"];
    [(UIButton *)controls.arrangedSubviews[6] sendActionsForControlEvents:UIControlEventPrimaryActionTriggered];
    [self later:.2 action:^{
        IPTVPlayerMenu *menu=[[self player] valueForKey:@"menu"];
        [self selectRow:[menu.table numberOfRowsInSection:0]-1];
        [[self player] togglePause];
        [self later:.5 action:^{
            [[self player] togglePause];[[self player] favorite];
            [self later:.5 action:^{
                if(self.cycle%2==0){[[self player] next];self.checks=0;[self later:.5 action:^{[self awaitPlaying:YES];}];}
                else [self prepareReturn];
            }];
        }];
    }];
}
- (void)prepareReturn {
    PlayerScreen *p=[self player];[p hideControls];
    [self later:.2 action:^{
        id focus=[UIFocusSystem focusSystemForEnvironment:p.view].focusedItem;
        if(focus!=[p valueForKey:@"focusSurface"]){[self finish:@"hidden controls lost playback focus"];return;}
        if(self.cycle%2)[self.library dismissViewControllerAnimated:YES completion:nil];else [p close];
        self.returnChecks=0;[self later:.5 action:^{[self checkReturn];}];
    }];
}
- (void)checkReturn {
    if(self.library.presentedViewController){
        if(++self.returnChecks<6){[self later:.5 action:^{[self checkReturn];}];return;}
        UIViewController *remaining=self.library.presentedViewController;
        [self finish:[NSString stringWithFormat:@"player still intercepts input after 3s, cycle %lu, dismissing %d, closing %@, transition %@",(unsigned long)self.cycle,remaining.isBeingDismissed,[remaining valueForKey:@"closing"],remaining.transitionCoordinator]];return;
    }
    UICollectionView *grid=[self.library valueForKey:@"grid"];
    NSUInteger index=8+self.cycle+(self.cycle%2==0?1:0);
    UICollectionViewCell *cell=[grid cellForItemAtIndexPath:[NSIndexPath indexPathForItem:index inSection:0]];
    id focus=[UIFocusSystem focusSystemForEnvironment:self.library.view].focusedItem;
    if(!cell||focus!=cell){[self finish:[NSString stringWithFormat:@"library focus missing after cycle %lu: %@",(unsigned long)self.cycle,focus]];return;}
    self.cycle++;[self openPlayer];
}
@end
int main(int argc,char **argv){@autoreleasepool{return UIApplicationMain(argc,argv,nil,NSStringFromClass(TestApp.class));}}
