#import <Foundation/Foundation.h>

// All native decoder operations are serialized away from UIKit. The UI only
// receives immutable snapshots; it never waits for the decoder to acknowledge.
@interface IPTVPlaybackEngine : NSObject
@property(nonatomic,copy) void (^changed)(NSDictionary *snapshot);
- (void)startChannel:(NSDictionary *)channel drawable:(id)drawable subtitleSize:(NSNumber *)size;
- (void)setPaused:(BOOL)paused;
- (void)setSubtitleSize:(NSNumber *)size;
- (void)selectSubtitle:(int)track;
- (void)selectAudio:(int)track;
- (void)invalidate;
@end
