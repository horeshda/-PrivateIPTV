#import "PlaybackEngine.h"
#import <TVVLCKit/TVVLCKit.h>
#import <AVFoundation/AVFoundation.h>

@interface VLCMediaPlayer (IPTVTextRenderer)
- (void)setTextRendererFontSize:(NSNumber *)fontSize;
@end
@interface IPTVPlaybackEngine ()
@property(nonatomic,strong) dispatch_queue_t queue;
@property(nonatomic,strong) dispatch_source_t timer;
@property(nonatomic,strong) VLCMediaPlayer *decoder;
@property(nonatomic,strong) id drawable;
@property(nonatomic,strong) NSNumber *fontSize;
@property(nonatomic) BOOL preferencesApplied;
@property(nonatomic) BOOL sizeApplied;
@property(atomic) BOOL closed;
@property(atomic) NSUInteger generation;
@end
@implementation IPTVPlaybackEngine
- (instancetype)init {
    if((self=[super init]))_queue=dispatch_queue_create("com.horesh.privateiptv.decoder",DISPATCH_QUEUE_SERIAL);
    return self;
}
// Only called on queue. Keep the drawable alive until native teardown is done;
// releasing the last UIView reference, however, belongs on the main queue.
- (void)retireDecoder {
    if(self.timer){dispatch_source_cancel(self.timer);self.timer=nil;}
    id surface=self.drawable;self.drawable=nil;
    @autoreleasepool {
        VLCMediaPlayer *old=self.decoder;self.decoder=nil;
        old.delegate=nil;[old stop];old.drawable=nil;old=nil;
    }
    if(surface)dispatch_async(dispatch_get_main_queue(),^{(void)[surface description];});
}
- (void)startChannel:(NSDictionary *)channel drawable:(id)drawable subtitleSize:(NSNumber *)size {
    if(self.closed)return;
    NSUInteger generation=++self.generation;
    dispatch_async(self.queue,^{
        [self retireDecoder];
        if(self.closed||generation!=self.generation){dispatch_async(dispatch_get_main_queue(),^{(void)[drawable description];});return;}
        self.drawable=drawable;self.fontSize=size;self.preferencesApplied=NO;self.sizeApplied=NO;
        [AVAudioSession.sharedInstance setCategory:AVAudioSessionCategoryPlayback mode:AVAudioSessionModeMoviePlayback options:0 error:nil];
        // VLC manages session activation. Do not race it with setActive:NO
        // from a screen that has just been dismissed.
        NSString *option=[NSString stringWithFormat:@"--freetype-rel-fontsize=%@",size];
        self.decoder=[[VLCMediaPlayer alloc]initWithOptions:@[@"--no-video-title-show",@"--quiet",option]];
        self.decoder.drawable=drawable;
        VLCMedia *media=[VLCMedia mediaWithURL:[NSURL URLWithString:channel[@"url"]]];
        [media addOption:@":network-caching=1500"];[media addOption:@":http-reconnect"];
        NSDictionary *headers=channel[@"headers"];
        for(NSString *key in @[@"User-Agent",@"Referer"]){
            NSString *value=headers[key];
            if([value isKindOfClass:NSString.class]&&value.length)
                [media addOption:[( [key isEqual:@"User-Agent"]?@":http-user-agent=":@":http-referrer=") stringByAppendingString:value]];
        }
        self.decoder.media=media;[self.decoder play];
        self.timer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,self.queue);
        dispatch_source_set_timer(self.timer,DISPATCH_TIME_NOW,400*NSEC_PER_MSEC,40*NSEC_PER_MSEC);
        __weak IPTVPlaybackEngine *weak=self;
        dispatch_source_set_event_handler(self.timer,^{[weak publishGeneration:generation];});
        dispatch_resume(self.timer);
    });
}
- (void)publishGeneration:(NSUInteger)generation {
    if(self.closed||generation!=self.generation||!self.decoder)return;
    VLCMediaPlayer *p=self.decoder;
    VLCMediaPlayerState state=p.state;
    // Track discovery can leave the cached enum at ESAdded during playback.
    BOOL playing=p.isPlaying;
    NSArray *subNames=[p.videoSubTitlesNames copy]?:@[],*subIDs=[p.videoSubTitlesIndexes copy]?:@[];
    BOOL canResize=[p respondsToSelector:@selector(setTextRendererFontSize:)];
    if(playing&&!self.sizeApplied&&canResize){[p setTextRendererFontSize:self.fontSize];self.sizeApplied=YES;}
    if(!self.preferencesApplied&&subIDs.count){
        NSUserDefaults *prefs=NSUserDefaults.standardUserDefaults;
        NSNumber *enabled=[prefs objectForKey:@"PrivateIPTV.subtitles.enabled"];
        NSString *name=[prefs stringForKey:@"PrivateIPTV.subtitles.name"];
        NSUInteger index=name?[subNames indexOfObject:name]:NSNotFound;
        if(enabled&&!enabled.boolValue){p.currentVideoSubTitleIndex=-1;self.preferencesApplied=YES;}
        else if(index!=NSNotFound&&index<subIDs.count){p.currentVideoSubTitleIndex=[subIDs[index] intValue];self.preferencesApplied=YES;}
        else if(!name)self.preferencesApplied=YES;
    }
    NSString *status=@"loading";
    if(playing)status=@"playing";
    else if(state==VLCMediaPlayerStatePaused)status=@"paused";
    else if(state==VLCMediaPlayerStateError)status=@"error";
    else if(state==VLCMediaPlayerStateEnded)status=@"ended";
    NSDictionary *snapshot=@{@"state":status,@"nativeState":@(state),@"time":p.time.value?:@0,@"subNames":subNames,@"subIDs":subIDs,
        @"audioNames":[p.audioTrackNames copy]?:@[],@"audioIDs":[p.audioTrackIndexes copy]?:@[],
        @"subtitle":@(p.currentVideoSubTitleIndex),@"audio":@(p.currentAudioTrackIndex),@"canResize":@(canResize),@"fontSize":self.fontSize};
    __weak IPTVPlaybackEngine *weak=self;
    dispatch_async(dispatch_get_main_queue(),^{
        IPTVPlaybackEngine *s=weak;if(s&&!s.closed&&generation==s.generation&&s.changed)s.changed(snapshot);
    });
}
- (void)setPaused:(BOOL)paused {
    dispatch_async(self.queue,^{if(self.closed)return;if(paused)[self.decoder pause];else [self.decoder play];});
}
- (void)setSubtitleSize:(NSNumber *)size {
    dispatch_async(self.queue,^{if(self.closed)return;self.fontSize=size;
        if([self.decoder respondsToSelector:@selector(setTextRendererFontSize:)]){[self.decoder setTextRendererFontSize:size];self.sizeApplied=YES;}
    });
}
- (void)selectSubtitle:(int)track {dispatch_async(self.queue,^{if(!self.closed){self.decoder.currentVideoSubTitleIndex=track;self.preferencesApplied=YES;}});}
- (void)selectAudio:(int)track {dispatch_async(self.queue,^{if(!self.closed)self.decoder.currentAudioTrackIndex=track;});}
- (void)invalidate {
    if(self.closed)return;self.closed=YES;self.generation++;self.changed=nil;
    // The block retains this engine until native teardown finishes off-main.
    dispatch_async(self.queue,^{[self retireDecoder];});
}
@end
