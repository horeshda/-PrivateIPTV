#import "PlayerMenu.h"
@interface IPTVPlayerMenu ()
@property(nonatomic,strong) UITableView *table;
@property(nonatomic,strong) UILabel *heading;
@property(nonatomic,strong) UIView *panel;
@property(nonatomic,strong) NSArray<NSString *> *rows;
@property(nonatomic) NSUInteger selectedRow;
@end
@implementation IPTVPlayerMenu
- (void)viewDidLoad {
    [super viewDidLoad];self.view.backgroundColor=[UIColor colorWithWhite:0 alpha:.62];
    self.panel=[UIView new];self.panel.backgroundColor=[UIColor colorWithWhite:.12 alpha:1];self.panel.layer.cornerRadius=20;[self.view addSubview:self.panel];
    self.heading=[UILabel new];self.heading.textColor=UIColor.whiteColor;self.heading.font=[UIFont systemFontOfSize:36 weight:UIFontWeightSemibold];self.heading.textAlignment=NSTextAlignmentCenter;[self.panel addSubview:self.heading];
    self.table=[[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
    self.table.delegate=self;self.table.dataSource=self;self.table.rowHeight=76;self.table.backgroundColor=UIColor.clearColor;
    self.table.remembersLastFocusedIndexPath=NO;[self.panel addSubview:self.table];
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];CGSize b=self.view.bounds.size;
    CGFloat width=MIN(900,b.width*.76),height=MIN(b.height-160,120+self.rows.count*76);
    self.panel.frame=CGRectMake((b.width-width)/2,(b.height-height)/2,width,height);
    self.heading.frame=CGRectMake(28,20,width-56,64);self.table.frame=CGRectMake(32,96,width-64,height-112);
}
- (void)showTitle:(NSString *)title rows:(NSArray<NSString *> *)rows selectedRow:(NSUInteger)row {
    [self loadViewIfNeeded];self.heading.text=title;self.rows=rows;self.selectedRow=row;
    [self.table reloadData];[self.view setNeedsLayout];[self.view layoutIfNeeded];
    NSUInteger target=row<rows.count?row:0;
    if(rows.count)[self.table scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:target inSection:0] atScrollPosition:UITableViewScrollPositionNone animated:NO];
    [self setNeedsFocusUpdate];[self updateFocusIfNeeded];
}
- (NSArray<id<UIFocusEnvironment>> *)preferredFocusEnvironments{return @[self.table];}
- (NSIndexPath *)indexPathForPreferredFocusedViewInTableView:(UITableView *)tableView{return [NSIndexPath indexPathForRow:self.selectedRow<self.rows.count?self.selectedRow:0 inSection:0];}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{return self.rows.count;}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"option"];
    if(!cell)cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"option"];
    cell.textLabel.text=self.rows[indexPath.row];cell.textLabel.font=[UIFont systemFontOfSize:28];
    cell.textLabel.textColor=UIColor.whiteColor;cell.backgroundColor=UIColor.clearColor;
    cell.accessoryType=indexPath.row==self.selectedRow?UITableViewCellAccessoryCheckmark:UITableViewCellAccessoryNone;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {if(self.selected)self.selected(indexPath.row);}
- (void)tableView:(UITableView *)tableView didUpdateFocusInContext:(UITableViewFocusUpdateContext *)context withAnimationCoordinator:(UIFocusAnimationCoordinator *)coordinator {
    UITableViewCell *old=[tableView cellForRowAtIndexPath:context.previouslyFocusedIndexPath],*next=[tableView cellForRowAtIndexPath:context.nextFocusedIndexPath];
    [coordinator addCoordinatedAnimations:^{old.textLabel.textColor=UIColor.whiteColor;next.textLabel.textColor=UIColor.blackColor;} completion:nil];
}
- (void)pressesBegan:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {
    for(UIPress *p in presses)if(p.type==UIPressTypeMenu){if(self.back)self.back();return;}
    [super pressesBegan:presses withEvent:event];
}
@end
