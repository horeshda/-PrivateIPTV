#import "LibraryScreen.h"
#import "PlaylistStore.h"
#import "PlayerScreen.h"
#import "Appearance.h"

static UIColor *Ink(void){return IPTVTextColor();}

@interface SidebarCell:UITableViewCell
@end
@implementation SidebarCell
- (void)updateColors {
    self.textLabel.textColor=self.isFocused?[UIColor colorWithWhite:.12 alpha:1]:Ink();
    self.tintColor=self.isFocused?UIColor.systemBlueColor:IPTVAccentColor();
}
- (void)didUpdateFocusInContext:(UIFocusUpdateContext *)context withAnimationCoordinator:(UIFocusAnimationCoordinator *)coordinator {
    [super didUpdateFocusInContext:context withAnimationCoordinator:coordinator];
    [coordinator addCoordinatedAnimations:^{[self updateColors];} completion:nil];
}
- (void)traitCollectionDidChange:(UITraitCollection *)previous {
    [super traitCollectionDidChange:previous];[self updateColors];
}
@end

@interface ChannelCell:UICollectionViewCell
@property(nonatomic,strong) UIImageView *logo;
@property(nonatomic,strong) UILabel *label;
@property(nonatomic,strong) UILabel *star;
@property(nonatomic,strong) NSURLSessionDataTask *imageTask;
@property(nonatomic,copy) NSString *representedID;
- (void)configure:(NSDictionary *)channel favorite:(BOOL)favorite cache:(NSCache *)cache;
@end
@implementation ChannelCell
- (instancetype)initWithFrame:(CGRect)frame {
    if((self=[super initWithFrame:frame])){
        self.contentView.backgroundColor=IPTVCardColor();self.contentView.layer.cornerRadius=18;
        self.logo=[UIImageView new];self.logo.contentMode=UIViewContentModeScaleAspectFit;[self.contentView addSubview:self.logo];
        self.label=[UILabel new];self.label.font=[UIFont systemFontOfSize:22 weight:UIFontWeightMedium];self.label.textColor=Ink();self.label.textAlignment=NSTextAlignmentCenter;self.label.numberOfLines=2;[self.contentView addSubview:self.label];
        self.star=[UILabel new];self.star.text=@"★";self.star.textColor=IPTVAccentColor();self.star.font=[UIFont systemFontOfSize:23];[self.contentView addSubview:self.star];
        self.isAccessibilityElement=YES;
    }return self;
}
- (void)layoutSubviews {
    [super layoutSubviews];CGFloat w=self.bounds.size.width,h=self.bounds.size.height;
    self.logo.frame=CGRectMake(26,20,w-52,h-85);self.label.frame=CGRectMake(10,h-62,w-20,54);self.star.frame=CGRectMake(w-34,8,30,30);
}
- (void)prepareForReuse {[super prepareForReuse];[self.imageTask cancel];self.imageTask=nil;self.representedID=nil;self.logo.image=nil;}
- (void)configure:(NSDictionary *)channel favorite:(BOOL)favorite cache:(NSCache *)cache {
    [self.imageTask cancel];self.representedID=channel[@"id"];self.label.text=channel[@"name"];self.accessibilityLabel=channel[@"name"];self.star.hidden=!favorite;self.logo.image=nil;
    NSString *url=channel[@"logo"];if(!url.length)return;
    UIImage *cached=[cache objectForKey:url];if(cached){self.logo.image=cached;return;}
    NSURL *target=[PlaylistStore URLFromText:url];if(!target)return;
    NSString *identifier=self.representedID;__weak ChannelCell *weak=self;
    NSURLRequest *request=[NSURLRequest requestWithURL:target cachePolicy:NSURLRequestReturnCacheDataElseLoad timeoutInterval:8];
    self.imageTask=[NSURLSession.sharedSession dataTaskWithRequest:request completionHandler:^(NSData *data,NSURLResponse *response,NSError *error){
        if(error||!data.length||data.length>2*1024*1024)return;
        UIImage *image=[UIImage imageWithData:data];if(!image||image.size.width>4096||image.size.height>4096)return;
        dispatch_async(dispatch_get_main_queue(), ^{[cache setObject:image forKey:url];ChannelCell *s=weak;if([s.representedID isEqual:identifier])s.logo.image=image;});
    }];[self.imageTask resume];
}
- (void)didUpdateFocusInContext:(UIFocusUpdateContext *)context withAnimationCoordinator:(UIFocusAnimationCoordinator *)coordinator {
    [super didUpdateFocusInContext:context withAnimationCoordinator:coordinator];
    [coordinator addCoordinatedAnimations:^{
        self.transform=self.isFocused?CGAffineTransformMakeScale(1.07,1.07):CGAffineTransformIdentity;
        self.contentView.layer.borderWidth=self.isFocused?3:0;
        self.contentView.layer.borderColor=[IPTVAccentColor() resolvedColorWithTraitCollection:self.traitCollection].CGColor;
        self.layer.zPosition=self.isFocused?2:0;
    } completion:nil];
}
- (void)traitCollectionDidChange:(UITraitCollection *)previous {
    [super traitCollectionDidChange:previous];
    self.contentView.layer.borderColor=[IPTVAccentColor() resolvedColorWithTraitCollection:self.traitCollection].CGColor;
}
@end

@interface AddSourceScreen:UIViewController
@property(nonatomic,strong) PlaylistStore *store;
@property(nonatomic,strong) UITextField *nameField;
@property(nonatomic,strong) UITextField *urlField;
@property(nonatomic,strong) UIStackView *stack;
@property(nonatomic,strong) UILabel *message;
@property(nonatomic,strong) UIButton *saveButton;
@property(nonatomic,strong) NSUUID *request;
@property(nonatomic,copy) void (^finished)(void);
@end
@implementation AddSourceScreen
- (void)viewDidLoad {
    [super viewDidLoad];self.view.backgroundColor=IPTVBackgroundColor();
    UILabel *heading=[UILabel new];heading.text=@"Add playlist";heading.textColor=Ink();heading.font=[UIFont systemFontOfSize:40 weight:UIFontWeightSemibold];heading.textAlignment=NSTextAlignmentCenter;
    self.nameField=[UITextField new];self.nameField.placeholder=@"Playlist name";self.nameField.text=@"My playlist";
    self.urlField=[UITextField new];self.urlField.placeholder=@"https://… / M3U URL";self.urlField.keyboardType=UIKeyboardTypeURL;
    for(UITextField *field in @[self.nameField,self.urlField]){
        field.borderStyle=UITextBorderStyleRoundedRect;field.autocorrectionType=UITextAutocorrectionTypeNo;field.autocapitalizationType=UITextAutocapitalizationTypeNone;
        [field.heightAnchor constraintEqualToConstant:70].active=YES;
    }
    self.urlField.textAlignment=NSTextAlignmentLeft;self.urlField.semanticContentAttribute=UISemanticContentAttributeForceLeftToRight;
    self.saveButton=[UIButton buttonWithType:UIButtonTypeSystem];[self.saveButton setTitle:@"Load playlist" forState:UIControlStateNormal];[self.saveButton addTarget:self action:@selector(save) forControlEvents:UIControlEventPrimaryActionTriggered];
    UIButton *cancel=[UIButton buttonWithType:UIButtonTypeSystem];[cancel setTitle:@"Back" forState:UIControlStateNormal];[cancel addTarget:self action:@selector(cancel) forControlEvents:UIControlEventPrimaryActionTriggered];
    self.message=[UILabel new];self.message.font=[UIFont systemFontOfSize:24];self.message.textColor=Ink();self.message.numberOfLines=3;self.message.textAlignment=NSTextAlignmentCenter;
    self.stack=[[UIStackView alloc]initWithArrangedSubviews:@[heading,self.nameField,self.urlField,self.saveButton,cancel,self.message]];self.stack.axis=UILayoutConstraintAxisVertical;self.stack.spacing=28;self.stack.translatesAutoresizingMaskIntoConstraints=NO;[self.view addSubview:self.stack];
    [NSLayoutConstraint activateConstraints:@[[self.stack.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],[self.stack.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor],[self.stack.widthAnchor constraintEqualToAnchor:self.view.widthAnchor multiplier:.60]]];
}
- (void)save {
    if(self.request)return;
    NSURL *url=[PlaylistStore URLFromText:self.urlField.text];if(!url){self.message.text=@"Enter a valid http:// or https:// URL.";return;}
    NSString *name=[self.nameField.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    self.saveButton.enabled=NO;self.nameField.enabled=NO;self.urlField.enabled=NO;self.message.text=@"Loading…";
    __weak AddSourceScreen *weak=self;
    self.request=[self.store loadName:name url:url sourceID:nil completion:^(NSString *error){
        AddSourceScreen *s=weak;if(!s)return;s.request=nil;s.saveButton.enabled=YES;s.nameField.enabled=YES;s.urlField.enabled=YES;
        if(error)s.message.text=error;else [s dismissViewControllerAnimated:YES completion:s.finished];
    }];
}
- (void)cancel {if(self.request)[self.store cancel:self.request];self.request=nil;[self dismissViewControllerAnimated:YES completion:nil];}
- (void)pressesBegan:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {for(UIPress *p in presses)if(p.type==UIPressTypeMenu){[self cancel];return;}[super pressesBegan:presses withEvent:event];}
- (void)viewDidDisappear:(BOOL)animated {[super viewDidDisappear:animated];if(self.request){[self.store cancel:self.request];self.request=nil;}}
@end

@interface LibraryScreen () <UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong) PlaylistStore *store;
@property(nonatomic,strong) UICollectionView *grid;
@property(nonatomic,strong) UITableView *sidebar;
@property(nonatomic,strong) UIStackView *toolbar;
@property(nonatomic,strong) UILabel *heading;
@property(nonatomic,strong) UILabel *empty;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic,strong) NSArray<NSDictionary *> *visible;
@property(nonatomic,strong) NSArray<NSString *> *groups;
@property(nonatomic,strong) NSCache *imageCache;
@property(nonatomic,copy) NSString *group;
@property(nonatomic,copy) NSString *sourceID;
@property(nonatomic,copy) NSString *query;
@property(nonatomic) BOOL favoritesOnly;
@property(nonatomic) BOOL refreshing;
@property(nonatomic,copy) NSString *refreshError;
@property(nonatomic) NSUInteger refreshGeneration;
@property(nonatomic) NSUInteger reloadGeneration;
@property(nonatomic,strong) dispatch_queue_t filterQueue;
@property(nonatomic,strong) UIButton *refreshButton;
@property(nonatomic,strong) UIButton *addButton;
@property(nonatomic,strong) UIButton *themeButton;
@property(nonatomic,weak) UIView *lastToolbarFocus;
@property(nonatomic,strong) UIFocusGuide *toolbarBridge;
@property(nonatomic,strong) UIFocusGuide *emptyGridBridge;
@property(nonatomic) BOOL focusInToolbar;
@property(nonatomic) BOOL focusInSidebar;
@property(nonatomic,copy) NSString *returnChannelID;
@property(nonatomic,strong) NSIndexPath *returnIndexPath;
@property(nonatomic) BOOL restoreChannelFocus;
@property(nonatomic,strong) NSMutableArray<NSUUID *> *refreshRequests;
@end
@implementation LibraryScreen
- (UIButton *)button:(NSString *)name action:(SEL)action {
    UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem];[b setTitle:name forState:UIControlStateNormal];
    b.titleLabel.font=[UIFont systemFontOfSize:32 weight:UIFontWeightSemibold];
    b.titleLabel.numberOfLines=1;b.titleLabel.adjustsFontSizeToFitWidth=YES;b.titleLabel.minimumScaleFactor=.9;
    b.contentEdgeInsets=UIEdgeInsetsMake(12,32,12,32);
    [b addTarget:self action:action forControlEvents:UIControlEventPrimaryActionTriggered];return b;
}
- (void)viewDidLoad {
    [super viewDidLoad];self.view.backgroundColor=IPTVBackgroundColor();self.view.tintColor=IPTVAccentColor();
    self.filterQueue=dispatch_queue_create("com.horesh.privateiptv.filter",DISPATCH_QUEUE_SERIAL);
    self.store=[PlaylistStore new];self.imageCache=[NSCache new];self.imageCache.countLimit=120;
    self.heading=[UILabel new];self.heading.text=@"Private IPTV";self.heading.font=[UIFont systemFontOfSize:36 weight:UIFontWeightSemibold];self.heading.textColor=Ink();[self.view addSubview:self.heading];
    self.refreshButton=[self button:@"↻" action:@selector(refresh)];self.refreshButton.accessibilityLabel=@"Refresh playlists";
    self.addButton=[self button:@"＋ Add playlist" action:@selector(add)];self.addButton.accessibilityLabel=@"Add playlist";
    self.themeButton=[self button:@"Theme" action:@selector(chooseTheme)];self.themeButton.accessibilityValue=IPTVAppearanceName();
    self.toolbar=[[UIStackView alloc]initWithArrangedSubviews:@[self.addButton, [self button:@"Playlists" action:@selector(sources)], [self button:@"Search" action:@selector(search)],self.refreshButton,self.themeButton]];
    self.toolbar.axis=UILayoutConstraintAxisHorizontal;self.toolbar.spacing=24;self.toolbar.distribution=UIStackViewDistributionFillProportionally;self.toolbar.semanticContentAttribute=UISemanticContentAttributeForceLeftToRight;[self.view addSubview:self.toolbar];
    self.sidebar=[[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];self.sidebar.delegate=self;self.sidebar.dataSource=self;self.sidebar.rowHeight=66;self.sidebar.backgroundColor=UIColor.clearColor;self.sidebar.remembersLastFocusedIndexPath=YES;[self.view addSubview:self.sidebar];
    UICollectionViewFlowLayout *layout=[UICollectionViewFlowLayout new];layout.minimumInteritemSpacing=25;layout.minimumLineSpacing=30;layout.sectionInset=UIEdgeInsetsMake(16,16,24,16);
    self.grid=[[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:layout];self.grid.backgroundColor=UIColor.clearColor;self.grid.delegate=self;self.grid.dataSource=self;self.grid.remembersLastFocusedIndexPath=NO;
    [self.grid registerClass:ChannelCell.class forCellWithReuseIdentifier:@"channel"];[self.view addSubview:self.grid];
    self.empty=[UILabel new];self.empty.font=[UIFont systemFontOfSize:29];self.empty.numberOfLines=3;self.empty.textAlignment=NSTextAlignmentCenter;self.empty.textColor=Ink();[self.view addSubview:self.empty];
    self.status=[UILabel new];self.status.font=[UIFont systemFontOfSize:20];self.status.textColor=UIColor.secondaryLabelColor;self.status.textAlignment=NSTextAlignmentRight;[self.view addSubview:self.status];
    // Bridge the full width between the toolbar and content. UIKit cannot
    // infer a vertical move between controls with no horizontal overlap.
    self.toolbarBridge=[UIFocusGuide new];[self.view addLayoutGuide:self.toolbarBridge];
    [NSLayoutConstraint activateConstraints:@[
        [self.toolbarBridge.leadingAnchor constraintEqualToAnchor:self.sidebar.leadingAnchor],
        [self.toolbarBridge.trailingAnchor constraintEqualToAnchor:self.grid.trailingAnchor],
        [self.toolbarBridge.topAnchor constraintEqualToAnchor:self.toolbar.bottomAnchor],
        [self.toolbarBridge.bottomAnchor constraintEqualToAnchor:self.grid.topAnchor]]];
    // With no channel cells, Right from Favorites must still lead somewhere.
    self.emptyGridBridge=[UIFocusGuide new];[self.view addLayoutGuide:self.emptyGridBridge];
    [NSLayoutConstraint activateConstraints:@[
        [self.emptyGridBridge.leadingAnchor constraintEqualToAnchor:self.grid.leadingAnchor],
        [self.emptyGridBridge.trailingAnchor constraintEqualToAnchor:self.grid.trailingAnchor],
        [self.emptyGridBridge.topAnchor constraintEqualToAnchor:self.grid.topAnchor],
        [self.emptyGridBridge.bottomAnchor constraintEqualToAnchor:self.grid.bottomAnchor]]];
    self.emptyGridBridge.preferredFocusEnvironments=@[self.addButton];
    UILongPressGestureRecognizer *hold=[[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPress:)];[self.grid addGestureRecognizer:hold];
    __weak LibraryScreen *weak=self;self.store.changed=^{[weak reload];};[self reload];
    // tvOS can purge Caches. Saved source URLs survive; restore their channels.
    [self.store restoreCachesWithCompletion:^{
        LibraryScreen *screen=weak;if(!screen)return;
        BOOL missing=NO;NSDictionary *catalog=screen.store.catalog;
        for(NSDictionary *source in screen.store.sources)if(!catalog[source[@"id"]])missing=YES;
        if(missing)[screen refresh];
    }];
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];CGFloat w=self.view.bounds.size.width,h=self.view.bounds.size.height,s=w/1920;
    self.heading.frame=CGRectMake(85*s,40*s,w-170*s,60*s);
    self.toolbar.frame=CGRectMake(65*s,125*s,w-130*s,80*s);
    self.toolbar.spacing=24*s;
    for(UIButton *button in self.toolbar.arrangedSubviews){
        button.titleLabel.font=[UIFont systemFontOfSize:32*s weight:UIFontWeightSemibold];
        button.contentEdgeInsets=UIEdgeInsetsMake(12*s,32*s,12*s,32*s);
    }
    self.sidebar.frame=CGRectMake(65*s,260*s,320*s,h-325*s);self.grid.frame=CGRectMake(410*s,245*s,w-490*s,h-315*s);
    self.empty.frame=CGRectInset(self.grid.frame,40,80);self.status.frame=CGRectMake(450*s,h-55*s,w-540*s,30*s);
    // Changing bounds already invalidates the flow layout. Invalidating here
    // on every layout pass can cause a perpetual relayout when returning.
}
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.toolbarBridge.enabled=YES;[self updateFocusRoutes];
    __weak LibraryScreen *weak=self;
    dispatch_async(dispatch_get_main_queue(),^{[weak restorePlaybackFocus];});
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.toolbarBridge.enabled=NO;self.emptyGridBridge.enabled=NO;
}
- (NSIndexPath *)playbackReturnPath {
    if(!self.visible.count)return nil;
    NSUInteger index=self.returnIndexPath?self.returnIndexPath.item:0;
    if(index>=self.visible.count||![self.visible[index][@"id"] isEqual:self.returnChannelID]){
        index=[self.visible indexOfObjectPassingTest:^BOOL(NSDictionary *channel,NSUInteger i,BOOL *stop){return [channel[@"id"] isEqual:self.returnChannelID];}];
        if(index==NSNotFound)index=MIN(self.returnIndexPath?self.returnIndexPath.item:0,self.visible.count-1);
    }
    return [NSIndexPath indexPathForItem:index inSection:0];
}
- (NSIndexPath *)indexPathForPreferredFocusedViewInCollectionView:(UICollectionView *)collectionView {
    return [self playbackReturnPath];
}
- (void)restorePlaybackFocus {
    if(!self.restoreChannelFocus||!self.view.window||self.presentedViewController)return;
    self.focusInToolbar=NO;self.focusInSidebar=NO;[self updateFocusRoutes];
    NSIndexPath *path=[self playbackReturnPath];self.returnIndexPath=path;
    if(path){
        if(![self.grid.indexPathsForVisibleItems containsObject:path])[self.grid scrollToItemAtIndexPath:path atScrollPosition:UICollectionViewScrollPositionCenteredVertically animated:NO];
        [self.grid layoutIfNeeded];
    }
    [self setNeedsFocusUpdate];[self updateFocusIfNeeded];
}
- (NSArray<id<UIFocusEnvironment>> *)preferredFocusEnvironments {
    if(self.restoreChannelFocus){
        NSIndexPath *path=[self playbackReturnPath];
        UICollectionViewCell *cell=path?[self.grid cellForItemAtIndexPath:path]:nil;
        if(cell)return @[cell,self.grid,self.addButton];
    }
    return self.visible.count?@[self.grid,self.addButton]:@[self.addButton,self.sidebar];
}
- (void)updateFocusRoutes {
    if(self.focusInToolbar){
        self.toolbarBridge.preferredFocusEnvironments=self.visible.count?@[self.grid,self.sidebar]:@[self.sidebar];
    }else{
        UIView *target=self.lastToolbarFocus;
        if(!target||([target isKindOfClass:UIControl.class]&&!((UIControl *)target).enabled))target=self.addButton;
        self.toolbarBridge.preferredFocusEnvironments=@[target];
    }
    self.emptyGridBridge.enabled=self.toolbarBridge.enabled&&!self.visible.count&&self.focusInSidebar;
}
- (void)didUpdateFocusInContext:(UIFocusUpdateContext *)context withAnimationCoordinator:(UIFocusAnimationCoordinator *)coordinator {
    [super didUpdateFocusInContext:context withAnimationCoordinator:coordinator];
    UIView *next=context.nextFocusedView;
    self.focusInToolbar=[next isDescendantOfView:self.toolbar];
    self.focusInSidebar=[next isDescendantOfView:self.sidebar];
    if(self.focusInToolbar)self.lastToolbarFocus=next;
    if([next isKindOfClass:ChannelCell.class]){
        NSIndexPath *path=[self.grid indexPathForCell:(UICollectionViewCell *)next];
        if(path&&(NSUInteger)path.item<self.visible.count){
            if(!self.restoreChannelFocus||[path isEqual:[self playbackReturnPath]]){
                self.returnIndexPath=path;self.returnChannelID=self.visible[path.item][@"id"];self.restoreChannelFocus=NO;
            }
        }
    }
    if(!self.visible.count&&next==self.addButton)self.restoreChannelFocus=NO;
    [self updateFocusRoutes];
}
- (void)chooseTheme {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"Theme" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    for(NSString *name in @[@"Light",@"Dark",@"System"]){
        NSString *title=[name isEqual:IPTVAppearanceName()]?[@"✓ " stringByAppendingString:name]:name;
        [alert addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
            IPTVSetAppearance(name,self.view.window);self.themeButton.accessibilityValue=name;
        }]];
    }
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)reload {
    NSArray *sources=self.store.sources;NSDictionary *catalog=self.store.catalog;NSSet *favorites=self.store.favorites;
    if(self.sourceID){BOOL found=NO;for(NSDictionary *source in sources)if([source[@"id"] isEqual:self.sourceID])found=YES;if(!found)self.sourceID=nil;}
    NSString *sourceID=self.sourceID,*group=self.group,*query=self.query;BOOL favoritesOnly=self.favoritesOnly;
    NSUInteger generation=++self.reloadGeneration;__weak LibraryScreen *weak=self;
    if(sources.count)self.status.text=@"Updating channels…";
    dispatch_async(self.filterQueue, ^{@autoreleasepool{
        NSMutableOrderedSet *groups=[NSMutableOrderedSet new];
        for(NSDictionary *source in sources){
            if(sourceID&&![sourceID isEqual:source[@"id"]])continue;
            for(NSDictionary *channel in catalog[source[@"id"]])[groups addObject:channel[@"group"]];
        }
        NSString *effectiveGroup=group&&[groups containsObject:group]?group:nil;
        NSMutableArray *filtered=[NSMutableArray new];
        for(NSDictionary *source in sources){
            if(sourceID&&![sourceID isEqual:source[@"id"]])continue;
            for(NSDictionary *channel in catalog[source[@"id"]]){
                if(favoritesOnly&&![favorites containsObject:channel[@"id"]])continue;
                if(effectiveGroup&&![effectiveGroup isEqual:channel[@"group"]])continue;
                if(query.length&&[channel[@"name"] rangeOfString:query options:NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch].location==NSNotFound)continue;
                [filtered addObject:channel];
            }
        }
        NSArray *groupNames=groups.array;
        dispatch_async(dispatch_get_main_queue(), ^{
            LibraryScreen *screen=weak;if(!screen||generation!=screen.reloadGeneration)return;
            screen.group=effectiveGroup;screen.groups=groupNames;screen.visible=filtered;
            [screen.sidebar reloadData];[screen.grid reloadData];screen.empty.hidden=filtered.count>0||!sources.count;
            screen.empty.text=!sources.count?@"":(favoritesOnly?@"No favorites":@"No channels found");
            NSString *title=@"Private IPTV";for(NSDictionary *source in sources)if([source[@"id"] isEqual:sourceID])title=source[@"name"];screen.heading.text=title;
            screen.status.text=query.length?[NSString stringWithFormat:@"%@ · %lu channels",query,(unsigned long)filtered.count]:[NSString stringWithFormat:@"%lu channels",(unsigned long)filtered.count];
            if(screen.refreshing)screen.status.text=@"Refreshing playlists…";
            else if(screen.refreshError)screen.status.text=screen.refreshError;
            [screen updateFocusRoutes];[screen restorePlaybackFocus];
        });
    }});
}
- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section{return self.groups.count+2;}
- (UITableViewCell *)tableView:(UITableView *)table cellForRowAtIndexPath:(NSIndexPath *)path {
    SidebarCell *cell=[table dequeueReusableCellWithIdentifier:@"group"]?:[[SidebarCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"group"];
    cell.textLabel.text=path.row==0?@"All channels":(path.row==1?@"★ Favorites":self.groups[path.row-2]);cell.textLabel.font=[UIFont systemFontOfSize:24];cell.backgroundColor=UIColor.clearColor;[cell updateColors];
    BOOL active=path.row==0?(!self.group&&!self.favoritesOnly):(path.row==1?self.favoritesOnly:[self.group isEqual:self.groups[path.row-2]]);
    cell.accessoryType=active?UITableViewCellAccessoryCheckmark:UITableViewCellAccessoryNone;return cell;
}
- (void)tableView:(UITableView *)table didSelectRowAtIndexPath:(NSIndexPath *)path {
    self.favoritesOnly=path.row==1;self.group=path.row>1?self.groups[path.row-2]:nil;[self reload];
}
- (NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section{return self.visible.count;}
- (UICollectionViewCell *)collectionView:(UICollectionView *)view cellForItemAtIndexPath:(NSIndexPath *)path {
    ChannelCell *cell=[view dequeueReusableCellWithReuseIdentifier:@"channel" forIndexPath:path];NSDictionary *c=self.visible[path.item];[cell configure:c favorite:[self.store.favorites containsObject:c[@"id"]] cache:self.imageCache];return cell;
}
- (CGSize)collectionView:(UICollectionView *)view layout:(UICollectionViewLayout *)layout sizeForItemAtIndexPath:(NSIndexPath *)path {
    CGFloat w=(view.bounds.size.width-32-4*25)/5;return CGSizeMake(MAX(150,w),MAX(150,w*.77));
}
- (void)collectionView:(UICollectionView *)view didSelectItemAtIndexPath:(NSIndexPath *)path {
    if((NSUInteger)path.item>=self.visible.count||self.presentedViewController)return;
    self.returnIndexPath=path;self.returnChannelID=self.visible[path.item][@"id"];self.restoreChannelFocus=YES;
    // Explicitly restore a live cell after dismissal instead of UIKit's cached
    // focus item, which may have been hidden or replaced while playback ran.
    self.restoresFocusAfterTransition=NO;
    PlayerScreen *player=[[PlayerScreen alloc]initWithChannels:self.visible index:path.item store:self.store];
    __weak LibraryScreen *weak=self;
    player.willClose=^(NSString *channelID){LibraryScreen *screen=weak;if(!screen)return;screen.returnChannelID=channelID;screen.restoreChannelFocus=YES;};
    [self presentViewController:player animated:NO completion:nil];
}
- (void)longPress:(UILongPressGestureRecognizer *)hold {
    if(hold.state!=UIGestureRecognizerStateBegan)return;
    for(NSIndexPath *path in self.grid.indexPathsForVisibleItems){ChannelCell *cell=(ChannelCell *)[self.grid cellForItemAtIndexPath:path];if(cell.isFocused){[self.store toggleFavorite:self.visible[path.item][@"id"]];return;}}
}
- (void)add {AddSourceScreen *form=[AddSourceScreen new];form.store=self.store;form.modalPresentationStyle=UIModalPresentationFullScreen;[self presentViewController:form animated:YES completion:nil];}
- (void)search {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"Search channels" message:nil preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field){field.text=self.query;field.placeholder=@"Channel name";}];
    [alert addAction:[UIAlertAction actionWithTitle:@"Search" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a){self.query=[alert.textFields.firstObject.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];[self reload];}]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Clear search" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a){self.query=nil;[self reload];}]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:alert animated:YES completion:nil];
}
- (void)sources {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"My playlists" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    [alert addAction:[UIAlertAction actionWithTitle:@"All playlists" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a){self.sourceID=nil;self.group=nil;[self reload];}]];
    for(NSDictionary *source in self.store.sources)[alert addAction:[UIAlertAction actionWithTitle:source[@"name"] style:UIAlertActionStyleDefault handler:^(UIAlertAction *a){self.sourceID=source[@"id"];self.group=nil;[self reload];}]];
    if(self.store.sources.count)[alert addAction:[UIAlertAction actionWithTitle:@"Delete playlist…" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a){[self chooseRemoval];}]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Back" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:alert animated:YES completion:nil];
}
- (void)chooseRemoval {
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"Delete playlist" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    for(NSDictionary *source in self.store.sources)[alert addAction:[UIAlertAction actionWithTitle:source[@"name"] style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a){
        UIAlertController *confirm=[UIAlertController alertControllerWithTitle:[@"Delete " stringByAppendingString:source[@"name"]] message:@"This playlist and its favorites will be removed from this device." preferredStyle:UIAlertControllerStyleAlert];
        [confirm addAction:[UIAlertAction actionWithTitle:@"Delete" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *b){[self cancelRefresh];[self.store removeSource:source[@"id"]];}]];
        [confirm addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:confirm animated:YES completion:nil];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:alert animated:YES completion:nil];
}
- (void)refresh {
    if(self.refreshing||!self.store.sources.count)return;
    self.refreshing=YES;self.refreshError=nil;self.refreshButton.enabled=NO;self.status.text=@"Refreshing playlists…";
    self.refreshRequests=[NSMutableArray new];
    NSUInteger generation=++self.refreshGeneration;__block NSUInteger pending=self.store.sources.count;__block NSString *firstError=nil;
    for(NSDictionary *source in self.store.sources){
        NSUUID *request=[self.store loadName:source[@"name"] url:[PlaylistStore URLFromText:source[@"url"]] sourceID:source[@"id"] completion:^(NSString *error){
            if(generation!=self.refreshGeneration)return;
            if(error&&!firstError)firstError=error;
            if(--pending==0){self.refreshing=NO;self.refreshButton.enabled=YES;self.refreshRequests=nil;self.refreshError=firstError?[firstError stringByAppendingString:@" The previous playlist was kept."]:nil;[self reload];}
        }];
        [self.refreshRequests addObject:request];
    }
}
- (void)cancelRefresh {
    self.refreshGeneration++;for(NSUUID *request in self.refreshRequests)[self.store cancel:request];
    self.refreshRequests=nil;self.refreshing=NO;self.refreshButton.enabled=YES;
}
@end
