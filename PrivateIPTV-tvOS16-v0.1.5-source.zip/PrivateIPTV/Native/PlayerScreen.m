#import "PlayerScreen.h"
#import "PlaylistStore.h"
#import "PlaybackEngine.h"
#import "PlayerMenu.h"
#import <AVFoundation/AVFoundation.h>

static NSArray<NSNumber *> *SubtitleSizes(void){return @[@48,@32,@24,@16];}
static NSArray<NSString *> *SubtitleSizeNames(void){return @[@"Small",@"Medium",@"Large",@"Extra large"];}
static NSNumber *SubtitleSize(void){
    NSNumber *saved=[NSUserDefaults.standardUserDefaults objectForKey:@"PrivateIPTV.subtitles.size"];
    return [SubtitleSizes() containsObject:saved]?saved:@32;
}
@interface IPTVVideoFocus:UIView
@property(nonatomic) BOOL available;
@end
@implementation IPTVVideoFocus
- (BOOL)canBecomeFocused{return self.available;}
@end
@interface PlayerScreen () <UIGestureRecognizerDelegate>
@property(nonatomic,strong) NSArray<NSDictionary *> *channels;
@property(nonatomic) NSUInteger index;
@property(nonatomic,strong) PlaylistStore *store;
@property(nonatomic,strong) IPTVPlaybackEngine *engine;
@property(nonatomic,strong) NSDictionary *snapshot;
@property(nonatomic,strong) UIView *surface;
@property(nonatomic,strong) IPTVVideoFocus *focusSurface;
@property(nonatomic,strong) IPTVPlayerMenu *menu;
@property(nonatomic,weak) UIButton *menuOrigin;
@property(nonatomic,strong) UIStackView *controls;
@property(nonatomic,strong) UILabel *titleLabel;
@property(nonatomic,strong) UIActivityIndicatorView *spinner;
@property(nonatomic,strong) UIButton *favoriteButton;
@property(nonatomic,strong) UIButton *pauseButton;
@property(nonatomic,strong) UIButton *retryButton;
@property(nonatomic,strong) NSTimer *hideTimer;
@property(nonatomic,strong) NSTimer *watchdog;
@property(nonatomic) NSUInteger generation;
@property(nonatomic) NSUInteger retries;
@property(nonatomic) BOOL paused;
@property(nonatomic) BOOL closing;
@property(nonatomic) BOOL suppressedSelect;
@end
@implementation PlayerScreen
- (instancetype)initWithChannels:(NSArray *)channels index:(NSUInteger)index store:(PlaylistStore *)store {
    if((self=[super init])){_channels=channels;_index=index;_store=store;self.modalPresentationStyle=UIModalPresentationFullScreen;}return self;
}
- (UIButton *)button:(NSString *)title action:(SEL)action {
    UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem];[b setTitle:title forState:UIControlStateNormal];
    b.titleLabel.font=[UIFont systemFontOfSize:28 weight:UIFontWeightSemibold];b.titleLabel.adjustsFontSizeToFitWidth=YES;b.titleLabel.minimumScaleFactor=.9;
    b.contentEdgeInsets=UIEdgeInsetsMake(12,24,12,24);
    [b addTarget:self action:action forControlEvents:UIControlEventPrimaryActionTriggered];return b;
}
- (void)viewDidLoad {
    [super viewDidLoad];self.view.backgroundColor=UIColor.blackColor;self.overrideUserInterfaceStyle=UIUserInterfaceStyleDark;
    self.engine=[IPTVPlaybackEngine new];
    __weak PlayerScreen *weak=self;self.engine.changed=^(NSDictionary *snapshot){[weak received:snapshot];};
    self.focusSurface=[IPTVVideoFocus new];[self.view addSubview:self.focusSurface];
    self.titleLabel=[UILabel new];self.titleLabel.textColor=UIColor.whiteColor;self.titleLabel.font=[UIFont systemFontOfSize:30 weight:UIFontWeightSemibold];self.titleLabel.textAlignment=NSTextAlignmentCenter;
    self.titleLabel.layer.shadowColor=UIColor.blackColor.CGColor;self.titleLabel.layer.shadowOpacity=1;self.titleLabel.layer.shadowRadius=4;[self.view addSubview:self.titleLabel];
    self.favoriteButton=[self button:@"☆" action:@selector(favorite)];
    self.pauseButton=[self button:@"Pause" action:@selector(togglePause)];
    self.controls=[[UIStackView alloc]initWithArrangedSubviews:@[[self button:@"Back" action:@selector(close)],[self button:@"Previous" action:@selector(previous)],self.pauseButton,[self button:@"Next" action:@selector(next)],self.favoriteButton,[self button:@"CC" action:@selector(subtitles)],[self button:@"Audio" action:@selector(audio)]]];
    self.controls.axis=UILayoutConstraintAxisHorizontal;self.controls.spacing=20;self.controls.distribution=UIStackViewDistributionFillProportionally;self.controls.semanticContentAttribute=UISemanticContentAttributeForceLeftToRight;
    [self.view addSubview:self.controls];
    self.retryButton=[self button:@"↻" action:@selector(manualRetry)];self.retryButton.accessibilityLabel=@"Retry";self.retryButton.hidden=YES;[self.view addSubview:self.retryButton];
    self.spinner=[[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];self.spinner.hidesWhenStopped=YES;[self.view addSubview:self.spinner];
    NSNotificationCenter *nc=NSNotificationCenter.defaultCenter;
    [nc addObserver:self selector:@selector(background) name:UIApplicationDidEnterBackgroundNotification object:nil];
    [nc addObserver:self selector:@selector(interrupted:) name:AVAudioSessionInterruptionNotification object:nil];
    for(NSNumber *direction in @[@(UISwipeGestureRecognizerDirectionUp),@(UISwipeGestureRecognizerDirectionDown),@(UISwipeGestureRecognizerDirectionLeft),@(UISwipeGestureRecognizerDirectionRight)]){
        UISwipeGestureRecognizer *g=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(wake:)];g.direction=direction.unsignedIntegerValue;g.cancelsTouchesInView=NO;g.delegate=self;[self.view addGestureRecognizer:g];
    }
    [self start];
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];CGRect b=self.view.bounds;CGFloat s=b.size.width/1920;
    self.surface.frame=b;self.focusSurface.frame=b;self.menu.view.frame=b;self.titleLabel.frame=CGRectMake(100*s,60*s,b.size.width-200*s,70*s);
    self.controls.frame=CGRectMake(110*s,b.size.height-170*s,b.size.width-220*s,80*s);
    self.controls.spacing=20*s;
    for(UIButton *button in self.controls.arrangedSubviews){button.titleLabel.font=[UIFont systemFontOfSize:28*s weight:UIFontWeightSemibold];button.contentEdgeInsets=UIEdgeInsetsMake(12*s,24*s,12*s,24*s);}
    self.spinner.center=CGPointMake(b.size.width/2,b.size.height/2);
    self.retryButton.frame=CGRectMake(b.size.width/2-60*s,b.size.height/2-50*s,120*s,100*s);
}
- (NSArray<id<UIFocusEnvironment>> *)preferredFocusEnvironments {
    if(self.menu)return @[self.menu];
    if(!self.retryButton.hidden)return @[self.retryButton];
    if(self.controls.hidden)return @[self.focusSurface];
    return @[self.menuOrigin?:self.pauseButton];
}
- (void)start {
    if(self.closing||self.index>=self.channels.count)return;
    self.generation++;self.paused=NO;self.snapshot=nil;
    [self.watchdog invalidate];self.watchdog=nil;
    NSDictionary *c=self.channels[self.index];self.titleLabel.text=c[@"name"];
    [self.favoriteButton setTitle:[self.store.favorites containsObject:c[@"id"]]?@"★":@"☆" forState:UIControlStateNormal];
    [self.pauseButton setTitle:@"Pause" forState:UIControlStateNormal];
    self.retryButton.hidden=YES;[self.spinner startAnimating];UIApplication.sharedApplication.idleTimerDisabled=YES;
    [self.surface removeFromSuperview];
    self.surface=[[UIView alloc]initWithFrame:self.view.bounds];self.surface.backgroundColor=UIColor.blackColor;self.surface.userInteractionEnabled=NO;
    [self.view insertSubview:self.surface atIndex:0];
    [self.engine startChannel:c drawable:self.surface subtitleSize:SubtitleSize()];
    [self showControls];[self armWatchdog];
}
- (void)received:(NSDictionary *)snapshot {
    if(self.closing)return;self.snapshot=snapshot;
    NSString *state=snapshot[@"state"];
    if([state isEqual:@"playing"]||[state isEqual:@"paused"]){
        [self.watchdog invalidate];self.watchdog=nil;[self.spinner stopAnimating];
    }else if([state isEqual:@"error"]){[self failed];}
    else if([state isEqual:@"ended"]){
        [self.watchdog invalidate];self.watchdog=nil;[self.spinner stopAnimating];
        self.retryButton.hidden=NO;UIApplication.sharedApplication.idleTimerDisabled=NO;[self showControls];
    }
}
- (void)armWatchdog {
    if(self.watchdog||self.paused||self.closing)return;
    NSUInteger g=self.generation;__weak PlayerScreen *weak=self;
    self.watchdog=[NSTimer scheduledTimerWithTimeInterval:30 repeats:NO block:^(NSTimer *t){PlayerScreen *s=weak;if(s&&s.generation==g)[s failed];}];
}
- (void)failed {
    if(self.closing||self.paused||!self.retryButton.hidden)return;
    [self.watchdog invalidate];self.watchdog=nil;[self.spinner stopAnimating];
    if(self.retries++<1){
        NSUInteger g=++self.generation;__weak PlayerScreen *weak=self;
        // Ignore further error snapshots until the replacement starts.
        self.retryButton.hidden=NO;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{PlayerScreen *s=weak;if(s&&!s.closing&&s.generation==g)[s start];});
    }else{self.retryButton.hidden=NO;UIApplication.sharedApplication.idleTimerDisabled=NO;[self showControls];[self setNeedsFocusUpdate];[self updateFocusIfNeeded];}
}
- (void)setSubtitleSize:(NSNumber *)size {
    if(self.closing||![SubtitleSizes() containsObject:size])return;
    [NSUserDefaults.standardUserDefaults setObject:size forKey:@"PrivateIPTV.subtitles.size"];
    [self.engine setSubtitleSize:size];
}
- (void)openMenu {
    [self.hideTimer invalidate];self.hideTimer=nil;
    self.controls.userInteractionEnabled=NO;self.focusSurface.available=NO;
    if(!self.menu){
        self.menu=[IPTVPlayerMenu new];[self addChildViewController:self.menu];
        self.menu.view.frame=self.view.bounds;[self.view addSubview:self.menu.view];[self.menu didMoveToParentViewController:self];
    }
}
- (void)closeMenu {
    self.menu.selected=nil;self.menu.back=nil;
    [self.menu willMoveToParentViewController:nil];[self.menu.view removeFromSuperview];[self.menu removeFromParentViewController];self.menu=nil;
    self.controls.userInteractionEnabled=YES;[self showControls];[self setNeedsFocusUpdate];[self updateFocusIfNeeded];
}
- (void)chooseSubtitleSize {
    if(self.closing)return;[self openMenu];
    [self.menu showTitle:@"Subtitle text size" rows:[SubtitleSizeNames() arrayByAddingObject:@"Back"] selectedRow:[SubtitleSizes() indexOfObject:SubtitleSize()]];
    __weak PlayerScreen *weak=self;
    self.menu.selected=^(NSUInteger row){PlayerScreen *s=weak;if(!s)return;if(row<SubtitleSizes().count){[s setSubtitleSize:SubtitleSizes()[row]];[s closeMenu];}else [s trackMenu:YES];};
    self.menu.back=^{[weak trackMenu:YES];};
    [self setNeedsFocusUpdate];[self updateFocusIfNeeded];
}
- (void)trackMenu:(BOOL)subtitle {
    if(self.closing)return;[self openMenu];
    NSArray *names=self.snapshot[subtitle?@"subNames":@"audioNames"]?:@[];
    NSArray *indices=self.snapshot[subtitle?@"subIDs":@"audioIDs"]?:@[];
    NSMutableArray *rows=[NSMutableArray new],*tracks=[NSMutableArray new];
    if(subtitle){[rows addObject:[NSString stringWithFormat:@"Text size: %@",SubtitleSizeNames()[[SubtitleSizes() indexOfObject:SubtitleSize()]]]];[tracks addObject:@-2];[rows addObject:@"Off"];[tracks addObject:@-1];}
    for(NSUInteger i=0;i<MIN(names.count,indices.count);i++)if([indices[i] intValue]>=0){[rows addObject:[names[i] description]];[tracks addObject:indices[i]];}
    [rows addObject:@"Back"];[tracks addObject:@-3];
    // Start at Text size, with all choices in a single child view hierarchy.
    [self.menu showTitle:subtitle?@"Subtitles":@"Audio track" rows:rows selectedRow:NSNotFound];
    __weak PlayerScreen *weak=self;
    self.menu.selected=^(NSUInteger row){
        PlayerScreen *s=weak;if(!s||row>=tracks.count)return;int track=[tracks[row] intValue];
        if(track==-2){[s chooseSubtitleSize];return;}
        if(track!=-3){
            if(subtitle){
                [s.engine selectSubtitle:track];[NSUserDefaults.standardUserDefaults setBool:track>=0 forKey:@"PrivateIPTV.subtitles.enabled"];
                if(track>=0)[NSUserDefaults.standardUserDefaults setObject:rows[row] forKey:@"PrivateIPTV.subtitles.name"];
            }else [s.engine selectAudio:track];
        }
        [s closeMenu];
    };
    self.menu.back=^{[weak closeMenu];};
    [self setNeedsFocusUpdate];[self updateFocusIfNeeded];
}
- (void)subtitles {self.menuOrigin=(UIButton *)self.controls.arrangedSubviews[5];[self trackMenu:YES];}
- (void)audio {self.menuOrigin=(UIButton *)self.controls.arrangedSubviews[6];[self trackMenu:NO];}
- (void)hideControls {
    if(self.closing||self.menu||self.paused||!self.retryButton.hidden)return;
    self.controls.hidden=YES;self.titleLabel.hidden=YES;self.focusSurface.available=YES;
    [self setNeedsFocusUpdate];[self updateFocusIfNeeded];
}
- (void)showControls {
    if(self.closing)return;
    BOOL wasHidden=self.controls.hidden;
    self.focusSurface.available=NO;self.controls.hidden=NO;self.titleLabel.hidden=NO;[self.hideTimer invalidate];
    if(wasHidden){[self setNeedsFocusUpdate];[self updateFocusIfNeeded];}
    if(self.menu)return;
    __weak PlayerScreen *weak=self;
    self.hideTimer=[NSTimer scheduledTimerWithTimeInterval:5 repeats:NO block:^(NSTimer *timer){[weak hideControls];}];
}
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {return self.controls.hidden&&!self.menu&&!self.closing;}
- (void)wake:(id)sender {if(!self.menu)[self showControls];}
- (void)didUpdateFocusInContext:(UIFocusUpdateContext *)context withAnimationCoordinator:(UIFocusAnimationCoordinator *)coordinator {
    [super didUpdateFocusInContext:context withAnimationCoordinator:coordinator];if(!self.controls.hidden&&!self.menu)[self showControls];
}
- (void)favorite {[self.store toggleFavorite:self.channels[self.index][@"id"]];[self.favoriteButton setTitle:[self.store.favorites containsObject:self.channels[self.index][@"id"]]?@"★":@"☆" forState:UIControlStateNormal];[self showControls];}
- (void)previous {if(self.index>0){self.index--;self.retries=0;[self start];}}
- (void)next {if(self.index+1<self.channels.count){self.index++;self.retries=0;[self start];}}
- (void)manualRetry {self.retries=0;[self start];}
- (void)togglePause {
    if(self.closing||self.menu)return;
    self.paused=!self.paused;[self.engine setPaused:self.paused];
    if(self.paused){[self.watchdog invalidate];self.watchdog=nil;[self.spinner stopAnimating];}else [self armWatchdog];
    UIApplication.sharedApplication.idleTimerDisabled=!self.paused;
    [self.pauseButton setTitle:self.paused?@"Play":@"Pause" forState:UIControlStateNormal];[self showControls];
}
- (void)background {if(!self.paused)[self togglePause];}
- (void)interrupted:(NSNotification *)note {if([note.userInfo[AVAudioSessionInterruptionTypeKey] integerValue]==AVAudioSessionInterruptionTypeBegan)[self background];}
- (void)beginClosing {
    if(self.closing)return;self.closing=YES;self.generation++;self.suppressedSelect=NO;
    [self.hideTimer invalidate];self.hideTimer=nil;[self.watchdog invalidate];self.watchdog=nil;
    self.menu.selected=nil;self.menu.back=nil;[NSNotificationCenter.defaultCenter removeObserver:self];
    [self.engine invalidate];self.engine=nil;UIApplication.sharedApplication.idleTimerDisabled=NO;
    void (^callback)(NSString *)=self.willClose;self.willClose=nil;
    if(callback)callback(self.index<self.channels.count?self.channels[self.index][@"id"]:nil);
}
- (void)close {if(self.closing)return;[self beginClosing];[self dismissViewControllerAnimated:YES completion:nil];}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];if(self.isBeingDismissed||self.presentingViewController.isBeingDismissed)[self beginClosing];
}
- (void)viewDidDisappear:(BOOL)animated {[super viewDidDisappear:animated];if(!self.presentingViewController)[self beginClosing];}
- (void)pressesBegan:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {
    if(self.closing)return;
    for(UIPress *p in presses){
        if(p.type==UIPressTypeMenu){if(self.menu){if(self.menu.back)self.menu.back();}else if(self.controls.hidden)[self showControls];else [self close];return;}
        if(p.type==UIPressTypePlayPause){[self togglePause];return;}
        if(self.controls.hidden){[self showControls];self.suppressedSelect=YES;return;}
    }[super pressesBegan:presses withEvent:event];
}
- (void)pressesEnded:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {if(self.suppressedSelect){self.suppressedSelect=NO;return;}[super pressesEnded:presses withEvent:event];}
- (void)pressesCancelled:(NSSet<UIPress *> *)presses withEvent:(UIPressesEvent *)event {self.suppressedSelect=NO;[super pressesCancelled:presses withEvent:event];}
- (void)dealloc {
    [NSNotificationCenter.defaultCenter removeObserver:self];[_hideTimer invalidate];[_watchdog invalidate];[_engine invalidate];
}
@end
