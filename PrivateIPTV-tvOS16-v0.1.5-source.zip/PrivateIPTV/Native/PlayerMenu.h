#import <UIKit/UIKit.h>
@interface IPTVPlayerMenu : UIViewController <UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong,readonly) UITableView *table;
@property(nonatomic,copy) void (^selected)(NSUInteger row);
@property(nonatomic,copy) void (^back)(void);
- (void)showTitle:(NSString *)title rows:(NSArray<NSString *> *)rows selectedRow:(NSUInteger)row;
@end
