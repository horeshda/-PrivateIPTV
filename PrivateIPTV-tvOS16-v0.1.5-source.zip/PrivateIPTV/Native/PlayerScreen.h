#import <UIKit/UIKit.h>
@class PlaylistStore;
@interface PlayerScreen : UIViewController
@property(nonatomic,copy) void (^willClose)(NSString *channelID);
- (instancetype)initWithChannels:(NSArray<NSDictionary *> *)channels index:(NSUInteger)index store:(PlaylistStore *)store;
@end
