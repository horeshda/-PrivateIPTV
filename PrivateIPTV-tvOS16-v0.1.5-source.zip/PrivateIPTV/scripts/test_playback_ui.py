"""Exercise production UI with the exact shipped TVVLCKit, not a decoder stub."""
import json, plistlib, shutil, subprocess, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def run(*args,timeout=120):
    subprocess.run(args,check=True,timeout=timeout)

def main(dependency_root):
    xc=next(Path(dependency_root).rglob('TVVLCKit.xcframework'))
    libraries=plistlib.loads((xc/'Info.plist').read_bytes())['AvailableLibraries']
    item=next((x for x in libraries if x.get('SupportedPlatform')=='tvos' and x.get('SupportedPlatformVariant')=='simulator' and 'arm64' in x['SupportedArchitectures']),None)
    if not item:raise RuntimeError('Real playback test requires TVVLCKit arm64 simulator slice')
    framework=xc/item['LibraryIdentifier']/item['LibraryPath']
    runtimes=json.loads(subprocess.check_output(['xcrun','simctl','list','runtimes','-j']))['runtimes']
    runtimes=[r for r in runtimes if r.get('isAvailable') and 'tvOS' in r['name']]
    if not runtimes:raise RuntimeError('Real playback regression requires a tvOS simulator runtime')
    runtime=sorted(runtimes,key=lambda r:tuple(map(int,r['version'].split('.'))))[-1]
    types=json.loads(subprocess.check_output(['xcrun','simctl','list','devicetypes','-j']))['devicetypes']
    device=next(d for d in types if d['name'].startswith('Apple TV 4K'))
    udid=subprocess.check_output(['xcrun','simctl','create','PrivateIPTV real playback regression',device['identifier'],runtime['identifier']],text=True).strip()
    try:
        run('xcrun','simctl','boot',udid)
        run('xcrun','simctl','bootstatus',udid,'-b',timeout=180)
        sdk=subprocess.check_output(['xcrun','--sdk','appletvsimulator','--show-sdk-path'],text=True).strip()
        with tempfile.TemporaryDirectory(prefix='iptv-ui-test-') as temp:
            app=Path(temp)/'PlaybackTests.app';app.mkdir()
            (app/'Info.plist').write_bytes(plistlib.dumps({'CFBundleIdentifier':'com.horesh.privateiptv.playbacktests','CFBundleExecutable':'PlaybackTests','CFBundleName':'PlaybackTests','CFBundlePackageType':'APPL','CFBundleVersion':'1','CFBundleShortVersionString':'1.0','MinimumOSVersion':'16.0','UIDeviceFamily':[3],'CFBundleSupportedPlatforms':['AppleTVSimulator'],'UILaunchScreen':{},'NSAppTransportSecurity':{'NSAllowsArbitraryLoads':True}}))
            sources=[str(p) for p in (ROOT/'Native').glob('*.m') if p.name!='main.m']
            command=['xcrun','--sdk','appletvsimulator','clang','-target','arm64-apple-tvos16.0-simulator','-isysroot',sdk,'-fobjc-arc','-fblocks','-O1','-Wno-deprecated-declarations','-F',str(framework.parent),*sources,str(ROOT/'Core/M3U.c'),str(ROOT/'tests/playback_ui.m')]
            for name in ['UIKit','Foundation','TVVLCKit','AVFoundation','CoreGraphics','QuartzCore','CoreText','AudioToolbox','OpenGLES','VideoToolbox','CoreMedia']:
                command+=['-framework',name]
            command+=['-lc++','-lxml2','-lz','-lbz2','-liconv','-lobjc','-Wl,-rpath,@executable_path/Frameworks','-o',str(app/'PlaybackTests')]
            run(*command)
            embedded=app/'Frameworks/TVVLCKit.framework';shutil.copytree(framework,embedded,symlinks=True)
            shutil.copy2(ROOT/'tests/Fixtures/playback.mp4',app/'playback.mp4')
            run('codesign','--force','--sign','-',str(embedded))
            run('codesign','--force','--sign','-',str(app))
            run('xcrun','simctl','install',udid,str(app))
            launched=subprocess.run(['xcrun','simctl','launch','--console',udid,'com.horesh.privateiptv.playbacktests'],timeout=240,capture_output=True,text=True)
            print(launched.stdout[-12000:]+launched.stderr[-6000:],flush=True)
            container=subprocess.check_output(['xcrun','simctl','get_app_container',udid,'com.horesh.privateiptv.playbacktests','data'],text=True).strip()
            result=(Path(container)/'Documents/playback-ui-result.txt').read_text()
            print(result,flush=True)
            if not result.startswith('PASS:'):raise RuntimeError(result)
            report={'status':'passed','runtime':runtime['name'],'cycles':6,'decoder':'actual TVVLCKit 3.7.4 simulator framework','fixture':'30-second H.264/AAC/English text subtitles','input':'UIControl actions and UITableView selection delegates; not physical remote events','checks':['all four subtitle sizes through CC menu','decoder playback time progresses','audio menu','pause/resume','next channel','favorites','hidden-controls focus','library focus after return','main-thread heartbeat']}
    finally:
        subprocess.run(['xcrun','simctl','shutdown',udid],check=False,capture_output=True)
        subprocess.run(['xcrun','simctl','delete',udid],check=False,capture_output=True)
    return report
